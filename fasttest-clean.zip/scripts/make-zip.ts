import AdmZip from 'adm-zip';
import path from 'path';
import fs from 'fs';

const distDir = path.resolve(process.cwd(), 'dist');
const publicDir = path.resolve(process.cwd(), 'public');

if (!fs.existsSync(distDir)) {
  console.error('dist directory does not exist! Run npm run build first.');
  process.exit(1);
}

if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

const zip = new AdmZip();
zip.addLocalFolder(distDir);
const zipPath = path.resolve(publicDir, 'fasttest-profit-daily.zip');
zip.writeZip(zipPath);
console.log('Successfully created zip at:', zipPath);
