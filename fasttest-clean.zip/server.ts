import express from 'express';
import { createServer as createViteServer } from 'vite';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Data directory & persistent db file
const DATA_DIR = path.resolve(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
const DB_FILE = path.resolve(DATA_DIR, 'db.json');

// Default initial state
const getInitialDb = () => ({
  accounts: [
    {
      id: 'usr_01',
      username: 'admin',
      phone: '03194815693',
      password: 'admin',
      investorId: 'inv_admin',
      createdAt: '2026-01-01'
    }
  ],
  investors: [
    {
      id: 'inv_admin',
      name: 'Admin',
      email: 'admin@fasttest.portal',
      phone: '03194815693',
      city: 'System',
      activePlanId: '',
      capitalInvestedPKR: 0,
      totalProfitEarnedPKR: 0,
      availableBalancePKR: 0,
      pendingWithdrawalPKR: 0,
      joinedDate: '2026-01-01',
      status: 'active'
    }
  ],
  depositRequests: [],
  withdrawalRequests: [],
  transactions: [
    {
      id: 'tx_01',
      investorId: 'inv_current',
      type: 'PROFIT',
      amountPKR: 315,
      descriptionEn: 'Daily trading return (2.10%) credited for Gold Scalp',
      descriptionUr: 'Daily trading return (2.10%) credited for Gold Scalp',
      date: '2026-10-24 15:30',
      status: 'COMPLETED'
    }
  ],
  tradeLogs: [
    {
      id: 'tl_01',
      date: '2026-10-24 14:30',
      assetPair: 'XAU/USD (Gold)',
      action: 'BUY',
      entryPrice: 2732.4,
      exitPrice: 2754.2,
      profitPercentage: 2.1,
      pnlPKR: 624000,
      notes: 'London session liquidity sweep below Asian low.',
      status: 'CLOSED'
    }
  ],
  dailyProfits: [
    {
      id: 'dp_01',
      investorId: 'inv_current',
      investorName: 'Farhan Ali (Admin / Investor)',
      date: '2026-10-24',
      returnPercentage: 2.1,
      amountPKR: 315,
      strategyName: 'Gold Scalp London & NY Session',
      tradePair: 'XAU/USD',
      status: 'credited'
    }
  ]
});

// Load DB
function loadDb() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Failed reading DB file, recreating default:', err);
  }
  const initial = getInitialDb();
  saveDb(initial);
  return initial;
}

// Save DB
function saveDb(data: any) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed writing DB file:', err);
  }
}

// Calculate daily profit ROI percentage according to deposit amount
function getDailyRoiRate(amountPKR: number): number {
  if (amountPKR >= 15000) return 20; // 15,000 PKR -> 20% daily (+Rs. 3,000/day)
  if (amountPKR >= 10000) return 15; // 10,000 PKR -> 15% daily (+Rs. 1,500/day)
  if (amountPKR >= 7000) return 10;  // 7,000 PKR -> 10% daily (+Rs. 700/day)
  if (amountPKR >= 3000) return 10;  // 3,000 PKR -> 10% daily (+Rs. 300/day)
  if (amountPKR >= 1000) return 7;   // 1,000 PKR -> 7% daily (+Rs. 70/day)
  return 7; // Default 7%
}

function getExpectedDailyProfit(amountPKR: number): number {
  if (amountPKR >= 15000) return Math.round(amountPKR * 0.20);
  if (amountPKR >= 10000) return Math.round(amountPKR * 0.15);
  if (amountPKR >= 7000) return Math.round(amountPKR * 0.10);
  if (amountPKR >= 3000) return Math.round(amountPKR * 0.10);
  if (amountPKR >= 1000) return 70;
  return Math.round(amountPKR * 0.07);
}

// Automatically check and distribute recurring 24-hour profits
function checkAndDistributeRecurringProfits(db: any): boolean {
  let changed = false;
  const now = Date.now();
  const todayStr = new Date().toISOString().split('T')[0];
  const nowTimeStr = new Date().toISOString().replace('T', ' ').substring(0, 16);

  if (!db.investors) return false;

  for (const inv of db.investors) {
    if (inv.capitalInvestedPKR > 0 && inv.status === 'active' && inv.nextProfitTimestamp) {
      if (now >= inv.nextProfitTimestamp) {
        const roiPercent = getDailyRoiRate(inv.capitalInvestedPKR);
        const profitAmount = getExpectedDailyProfit(inv.capitalInvestedPKR);

        inv.availableBalancePKR = (inv.availableBalancePKR || 0) + profitAmount;
        inv.totalProfitEarnedPKR = (inv.totalProfitEarnedPKR || 0) + profitAmount;
        inv.lastProfitTimestamp = now;
        inv.nextProfitTimestamp = now + 24 * 60 * 60 * 1000;

        // Record Daily Profit Entry
        if (!db.dailyProfits) db.dailyProfits = [];
        db.dailyProfits.unshift({
          id: `dp_auto_${Date.now()}_${inv.id}`,
          investorId: inv.id,
          investorName: inv.name,
          date: todayStr,
          returnPercentage: roiPercent,
          amountPKR: profitAmount,
          strategyName: '24-Hour Automated Cycle Return',
          tradePair: 'XAU/USD (Gold)',
          status: 'credited'
        });

        // Record Transaction
        if (!db.transactions) db.transactions = [];
        db.transactions.unshift({
          id: `tx_auto_${Date.now()}_${inv.id}`,
          investorId: inv.id,
          type: 'PROFIT',
          amountPKR: profitAmount,
          descriptionEn: `24-Hour Cycle Profit (+${roiPercent}% = Rs. ${profitAmount.toLocaleString()}) Automatically Credited to Available Balance`,
          descriptionUr: `24 گھنٹے بعد کا ڈیلی منافع (${roiPercent}% = ${profitAmount.toLocaleString()} روپے) خودکار طور پر بیلنس میں جمع ہو گیا`,
          date: nowTimeStr,
          status: 'COMPLETED'
        });

        console.log(`[24H AUTO PROFIT] Distributed Rs. ${profitAmount} (+${roiPercent}%) to ${inv.name}`);
        changed = true;
      }
    }
  }

  if (changed) {
    saveDb(db);
  }
  return changed;
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // Enable CORS for external APKs, Netlify hosting, and mobile clients
  app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    next();
  });

  // Background recurring 24h profit scheduler check (every 10 seconds)
  setInterval(() => {
    try {
      const db = loadDb();
      checkAndDistributeRecurringProfits(db);
    } catch (e) {
      // ignore
    }
  }, 10000);

  // Direct Binary Zip / Tarball Download
  app.get(['/fasttest-profit-daily.zip', '/fasttest-profit-daily.tar.gz', '/download', '/zip', '/download-project', '/project.zip'], (req, res) => {
    const zipPath = path.resolve(__dirname, 'public/fasttest-profit-daily.zip');
    const tarPath = path.resolve(__dirname, 'public/fasttest-profit-daily.tar.gz');

    if (fs.existsSync(zipPath)) {
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="fasttest-profit-daily.zip"');
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      fs.createReadStream(zipPath).pipe(res);
    } else if (fs.existsSync(tarPath)) {
      res.setHeader('Content-Type', 'application/gzip');
      res.setHeader('Content-Disposition', 'attachment; filename="fasttest-profit-daily.tar.gz"');
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      fs.createReadStream(tarPath).pipe(res);
    } else {
      res.status(404).send('Archive not ready');
    }
  });

  // REST API Endpoints

  // 1. Get live global state (auto-checks 24h recurring payouts on every fetch)
  app.get('/api/state', (req, res) => {
    const db = loadDb();
    checkAndDistributeRecurringProfits(db);
    res.json({
      accounts: db.accounts || [],
      investors: db.investors,
      depositRequests: db.depositRequests,
      withdrawalRequests: db.withdrawalRequests,
      transactions: db.transactions,
      tradeLogs: db.tradeLogs,
      dailyProfits: db.dailyProfits
    });
  });

  // Check profits explicitly
  app.post('/api/check-profits', (req, res) => {
    const db = loadDb();
    const updated = checkAndDistributeRecurringProfits(db);
    res.json({ success: true, updated });
  });

  // 2. Register account
  app.post('/api/register', (req, res) => {
    const { username, phone, password, investorId, accountId, referralCode } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password required' });
    }

    const db = loadDb();
    const cleanUser = username.trim().toLowerCase();
    const exists = db.accounts.some((a: any) => a.username.toLowerCase() === cleanUser);
    if (exists) {
      return res.status(400).json({ error: 'Username already registered. Please choose another.' });
    }

    const cleanRef = referralCode ? String(referralCode).trim().toLowerCase() : '';

    const newInvestorId = investorId || `inv_${Date.now()}`;
    const newAccount = {
      id: accountId || `usr_${Date.now()}`,
      username: username.trim(),
      phone: phone || '',
      password: password.trim(),
      investorId: newInvestorId,
      referredBy: cleanRef,
      createdAt: new Date().toISOString().split('T')[0]
    };

    const newInvestor = {
      id: newInvestorId,
      name: username.trim(),
      email: `${cleanUser}@fasttest.portal`,
      phone: phone || '',
      city: 'Online Investor',
      activePlanId: '',
      capitalInvestedPKR: 0,
      totalProfitEarnedPKR: 0,
      availableBalancePKR: 0,
      pendingWithdrawalPKR: 0,
      joinedDate: new Date().toISOString().split('T')[0],
      status: 'active',
      referralCode: cleanUser,
      referredByCode: cleanRef,
      totalReferralEarningsPKR: 0,
      totalReferredUsersCount: 0,
      awardedBonusMilestones: 0
    };

    // If referral code used, increment count on referrer & check 5-member milestone
    if (cleanRef) {
      const refInv = db.investors.find((i: any) =>
        i.name.toLowerCase() === cleanRef ||
        i.id.toLowerCase() === cleanRef ||
        (i.referralCode && i.referralCode.toLowerCase() === cleanRef)
      );
      if (refInv) {
        const newCount = (refInv.totalReferredUsersCount || 0) + 1;
        const currentMilestones = refInv.awardedBonusMilestones || 0;
        const targetMilestones = Math.floor(newCount / 5);

        refInv.totalReferredUsersCount = newCount;

        if (targetMilestones > currentMilestones) {
          const bonusAmount = (targetMilestones - currentMilestones) * 3000;
          const nowTimeStr = new Date().toISOString().replace('T', ' ').substring(0, 16);

          refInv.awardedBonusMilestones = targetMilestones;
          refInv.totalReferralEarningsPKR = (refInv.totalReferralEarningsPKR || 0) + bonusAmount;
          refInv.availableBalancePKR = (refInv.availableBalancePKR || 0) + bonusAmount;
          refInv.totalProfitEarnedPKR = (refInv.totalProfitEarnedPKR || 0) + bonusAmount;

          if (!db.transactions) db.transactions = [];
          db.transactions.unshift({
            id: `tx_ref_bonus_${Date.now()}_${refInv.id}`,
            investorId: refInv.id,
            type: 'PROFIT',
            amountPKR: bonusAmount,
            descriptionEn: `🎁 Referral Reward: 5 Active Members Invited! (+Rs. ${bonusAmount.toLocaleString()} Cash Bonus Credited)`,
            descriptionUr: `🎁 ریفرل انعام: 5 ممبرز جوڑنے پر ${bonusAmount.toLocaleString()} روپے کیش بونس اکاؤنٹ میں شامل!`,
            date: nowTimeStr,
            status: 'COMPLETED'
          });
        }
      }
    }

    db.accounts.push(newAccount);
    db.investors.push(newInvestor);
    saveDb(db);

    res.json({ success: true, account: newAccount, investor: newInvestor });
  });

  // 3. Login
  app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password required' });
    }

    const db = loadDb();
    const cleanUser = username.trim().toLowerCase();
    const cleanPass = password.trim();

    const account = db.accounts.find(
      (a: any) =>
        (a.username.toLowerCase() === cleanUser || a.phone === cleanUser) &&
        a.password === cleanPass
    );

    if (!account) {
      return res.status(401).json({ error: 'Invalid username or password.' });
    }

    const investor = db.investors.find((i: any) => i.id === account.investorId) || db.investors[0];
    const isAdmin = cleanUser === 'admin' || cleanUser === 'farhan' || cleanUser === 'zeeshantrader295@gmail.com';

    if (investor && (investor.status === 'paused' || investor.status === 'blocked') && !isAdmin) {
      return res.status(403).json({
        error: 'Your account has been suspended by Fund Administration for policy review. Contact @FASTTEST_ADMIN on Telegram.'
      });
    }

    res.json({ success: true, account, investor, isAdmin });
  });

  // Block Investor Account
  app.post('/api/investors/:id/block', (req, res) => {
    const { id } = req.params;
    const db = loadDb();
    const inv = db.investors.find((i: any) => i.id === id);
    if (!inv) return res.status(404).json({ error: 'Investor account not found' });
    inv.status = 'paused';
    saveDb(db);
    console.log(`[ACCOUNT BLOCKED] Admin blocked account ${id} (${inv.name})`);
    res.json({ success: true, investor: inv });
  });

  // Unblock Investor Account
  app.post('/api/investors/:id/unblock', (req, res) => {
    const { id } = req.params;
    const db = loadDb();
    const inv = db.investors.find((i: any) => i.id === id);
    if (!inv) return res.status(404).json({ error: 'Investor account not found' });
    inv.status = 'active';
    saveDb(db);
    console.log(`[ACCOUNT UNBLOCKED] Admin unblocked account ${id} (${inv.name})`);
    res.json({ success: true, investor: inv });
  });

  // 4. Submit Deposit Request (Any user anywhere)
  app.post('/api/deposits', (req, res) => {
    const { planId, amountPKR, paymentMethod, senderAccountNumber, transactionId, proofNote, investorId, investorName } = req.body;
    
    if (!amountPKR || !transactionId || !paymentMethod) {
      return res.status(400).json({ error: 'Missing required deposit fields' });
    }

    const db = loadDb();
    const targetInvestorId = investorId || 'inv_current';
    const targetInvestorName = investorName || 'Online Investor';

    // Ensure investor exists in db.investors
    let inv = db.investors.find((i: any) => i.id === targetInvestorId);
    if (!inv) {
      inv = {
        id: targetInvestorId,
        name: targetInvestorName,
        email: `${targetInvestorName.toLowerCase().replace(/[^a-z0-9]/g, '')}@fasttest.pk`,
        phone: senderAccountNumber || '',
        city: 'Online Investor',
        activePlanId: planId || 'plan_starter',
        capitalInvestedPKR: 0,
        totalProfitEarnedPKR: 0,
        availableBalancePKR: 0,
        pendingWithdrawalPKR: 0,
        joinedDate: new Date().toISOString().split('T')[0],
        status: 'active'
      };
      db.investors.push(inv);
    }

    const newDeposit = {
      id: `dep_${Date.now()}`,
      investorId: targetInvestorId,
      investorName: targetInvestorName,
      planId: planId || 'plan_starter',
      amountPKR: Number(amountPKR),
      paymentMethod,
      senderAccountNumber: senderAccountNumber || '',
      transactionId: transactionId.trim(),
      status: 'pending',
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
      adminNote: proofNote || ''
    };

    db.depositRequests.unshift(newDeposit);

    // Also add pending transaction with method and referenceId
    const newTx = {
      id: `tx_${Date.now()}`,
      investorId: newDeposit.investorId,
      type: 'DEPOSIT',
      paymentMethod,
      referenceId: newDeposit.transactionId,
      amountPKR: newDeposit.amountPKR,
      descriptionEn: `Deposit of Rs. ${newDeposit.amountPKR.toLocaleString()} via ${paymentMethod.toUpperCase()} (Ref: ${transactionId}) - Pending Admin Verification`,
      descriptionUr: `Deposit of Rs. ${newDeposit.amountPKR.toLocaleString()} via ${paymentMethod.toUpperCase()} (Ref: ${transactionId})`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'PENDING'
    };
    db.transactions.unshift(newTx);

    saveDb(db);
    console.log(`[DEPOSIT SUBMITTED] New deposit of Rs. ${amountPKR} from ${newDeposit.investorName} (TID: ${transactionId})`);

    res.json({ success: true, deposit: newDeposit });
  });

  // 5. Admin Approve Deposit (Credits the investor's capital, awards instant first profit, starts 24h real timer)
  app.post('/api/deposits/:id/approve', (req, res) => {
    const { id } = req.params;
    const db = loadDb();

    const deposit = db.depositRequests.find((d: any) => d.id === id);
    if (!deposit) {
      return res.status(404).json({ error: 'Deposit request not found' });
    }

    if (deposit.status === 'approved') {
      return res.status(400).json({ error: 'Deposit already approved' });
    }

    deposit.status = 'approved';
    const now = Date.now();
    const nowTimeStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const todayStr = new Date().toISOString().split('T')[0];

    // Calculate exact daily profit ROI %
    const roiPercent = getDailyRoiRate(deposit.amountPKR);
    const firstProfitAmount = getExpectedDailyProfit(deposit.amountPKR);

    // Ensure target investor exists
    let targetInv = db.investors.find(
      (inv: any) =>
        inv.id === deposit.investorId ||
        (deposit.investorName && inv.name.toLowerCase() === deposit.investorName.toLowerCase())
    );
    if (!targetInv) {
      targetInv = {
        id: deposit.investorId,
        name: deposit.investorName || 'Investor',
        email: `${(deposit.investorName || 'investor').toLowerCase().replace(/[^a-z0-9]/g, '')}@fasttest.pk`,
        phone: deposit.senderAccountNumber || '',
        city: 'Online Investor',
        activePlanId: deposit.planId || 'plan_starter',
        capitalInvestedPKR: 0,
        totalProfitEarnedPKR: 0,
        availableBalancePKR: 0,
        pendingWithdrawalPKR: 0,
        joinedDate: todayStr,
        status: 'active'
      };
      db.investors.push(targetInv);
    }

    targetInv.capitalInvestedPKR = (targetInv.capitalInvestedPKR || 0) + deposit.amountPKR;
    targetInv.availableBalancePKR = (targetInv.availableBalancePKR || 0) + firstProfitAmount;
    targetInv.totalProfitEarnedPKR = (targetInv.totalProfitEarnedPKR || 0) + firstProfitAmount;
    targetInv.activePlanId = deposit.planId || targetInv.activePlanId;
    targetInv.lastApprovedDepositAt = now;
    targetInv.lastProfitTimestamp = now;
    targetInv.nextProfitTimestamp = now + 24 * 60 * 60 * 1000;

    // Update pending deposit transaction to COMPLETED
    let foundTx = false;
    db.transactions = db.transactions.map((tx: any) => {
      if (
        tx.investorId === deposit.investorId &&
        tx.type === 'DEPOSIT' &&
        tx.status === 'PENDING' &&
        !foundTx
      ) {
        foundTx = true;
        return {
          ...tx,
          status: 'COMPLETED',
          descriptionEn: `Deposit of Rs. ${deposit.amountPKR.toLocaleString()} APPROVED & ACTIVATED (Ref: ${deposit.transactionId})`,
          descriptionUr: `Deposit of Rs. ${deposit.amountPKR.toLocaleString()} APPROVED & ACTIVATED`
        };
      }
      return tx;
    });

    if (!foundTx) {
      db.transactions.unshift({
        id: `tx_appr_${Date.now()}`,
        investorId: deposit.investorId,
        type: 'DEPOSIT',
        paymentMethod: deposit.paymentMethod,
        referenceId: deposit.transactionId,
        amountPKR: deposit.amountPKR,
        descriptionEn: `Deposit of Rs. ${deposit.amountPKR.toLocaleString()} APPROVED & ACTIVATED (Ref: ${deposit.transactionId})`,
        descriptionUr: `Deposit of Rs. ${deposit.amountPKR.toLocaleString()} APPROVED & ACTIVATED`,
        date: nowTimeStr,
        status: 'COMPLETED'
      });
    }

    // Add Instant Day 1 Profit Transaction (Withdrawable)
    db.transactions.unshift({
      id: `tx_first_profit_${Date.now()}`,
      investorId: deposit.investorId,
      type: 'PROFIT',
      amountPKR: firstProfitAmount,
      descriptionEn: `First Day 24h Profit (+${roiPercent}% = Rs. ${firstProfitAmount.toLocaleString()}) Credited upon Deposit Approval (Withdrawable)`,
      descriptionUr: `پہلے دن کا منافع (+${roiPercent}% = ${firstProfitAmount.toLocaleString()} روپے) منظور ہوتے ہی بیلنس میں شامل (فوری وڈرا کے لیے تیار)`,
      date: nowTimeStr,
      status: 'COMPLETED'
    });

    // Add to dailyProfits log
    if (!db.dailyProfits) db.dailyProfits = [];
    db.dailyProfits.unshift({
      id: `dp_first_${Date.now()}_${deposit.investorId}`,
      investorId: deposit.investorId,
      investorName: deposit.investorName,
      date: todayStr,
      returnPercentage: roiPercent,
      amountPKR: firstProfitAmount,
      strategyName: 'Instant Day 1 Profit (24h Real Cycle Active)',
      tradePair: 'XAU/USD (Gold)',
      status: 'credited'
    });

    // 5-Qualified Referrals (Min Rs. 3,000 deposit each) -> Rs. 3,000 Cash Bonus Credited to Referrer
    const invAccount = db.accounts.find(
      (a: any) =>
        a.investorId === targetInv.id ||
        a.username.toLowerCase() === targetInv.name.toLowerCase()
    );
    const referrerCode = targetInv.referredByCode || (invAccount && invAccount.referredBy);

    if (referrerCode) {
      const cleanRef = referrerCode.trim().toLowerCase();
      const referrerAccount = db.accounts.find(
        (a: any) =>
          a.username.toLowerCase() === cleanRef ||
          a.id.toLowerCase() === cleanRef ||
          a.investorId.toLowerCase() === cleanRef
      );
      const referrerInv = db.investors.find(
        (i: any) =>
          (referrerAccount && i.id === referrerAccount.investorId) ||
          i.name.toLowerCase() === cleanRef ||
          i.id.toLowerCase() === cleanRef ||
          (i.referralCode && i.referralCode.toLowerCase() === cleanRef)
      );

      if (referrerInv) {
        // Collect all users referred by this referrer
        const refAccounts = db.accounts.filter(
          (a: any) =>
            a.referredBy &&
            a.referredBy.toLowerCase() === (referrerAccount ? referrerAccount.username.toLowerCase() : cleanRef)
        );
        const refInvestorIds = refAccounts.map((a: any) => a.investorId);

        // A referral is qualified if total capital invested is at least 3,000 PKR
        const qualifiedInvestors = db.investors.filter(
          (i: any) =>
            (refInvestorIds.includes(i.id) ||
              (i.referredByCode && i.referredByCode.toLowerCase() === cleanRef)) &&
            (i.capitalInvestedPKR || 0) >= 3000
        );

        const qualifiedCount = qualifiedInvestors.length;
        const currentMilestones = Math.floor(qualifiedCount / 5);
        const alreadyAwarded = referrerInv.awardedBonusMilestones || 0;

        if (currentMilestones > alreadyAwarded) {
          const newMilestonesAwarded = currentMilestones - alreadyAwarded;
          const bonusAmountPKR = newMilestonesAwarded * 3000;

          referrerInv.availableBalancePKR = (referrerInv.availableBalancePKR || 0) + bonusAmountPKR;
          referrerInv.totalReferralEarningsPKR = (referrerInv.totalReferralEarningsPKR || 0) + bonusAmountPKR;
          referrerInv.awardedBonusMilestones = currentMilestones;

          // Record bonus transaction
          db.transactions.unshift({
            id: `tx_ref_bonus_${Date.now()}_${referrerInv.id}`,
            investorId: referrerInv.id,
            type: 'REFERRAL_COMMISSION',
            amountPKR: bonusAmountPKR,
            descriptionEn: `Milestone Referral Reward: 5 Active Investors with Rs. 3,000+ Deposit Completed! (+Rs. ${bonusAmountPKR.toLocaleString()} Cash Bonus Credited)`,
            descriptionUr: `ریفرل سنگ میل انعام: 5 ایکٹو انویسٹرز (3,000+ روپے ڈپازٹ) مکمل! ${bonusAmountPKR.toLocaleString()} روپے نقد بونس بیلنس میں شامل (فوری وڈرا کے لیے تیار)`,
            date: nowTimeStr,
            status: 'COMPLETED'
          });

          console.log(
            `[REFERRAL MILESTONE BONUS] Credited Rs. ${bonusAmountPKR} to ${referrerInv.name} for achieving ${qualifiedCount} qualified referrals!`
          );
        }
      }
    }

    saveDb(db);
    console.log(`[DEPOSIT APPROVED & 1ST PROFIT CREDITED] Admin approved deposit ${id} for ${deposit.investorName}. Capital: Rs. ${deposit.amountPKR}, Instant Profit: Rs. ${firstProfitAmount} credited.`);

    res.json({ success: true, deposit, firstProfitAmount, nextProfitTimestamp: now + 24 * 60 * 60 * 1000 });
  });

  // 6. Admin Reject Deposit
  app.post('/api/deposits/:id/reject', (req, res) => {
    const { id } = req.params;
    const db = loadDb();

    const deposit = db.depositRequests.find((d: any) => d.id === id);
    if (!deposit) {
      return res.status(404).json({ error: 'Deposit not found' });
    }

    deposit.status = 'rejected';

    // Update pending deposit transaction to REJECTED
    let foundTx = false;
    db.transactions = db.transactions.map((tx: any) => {
      if (
        tx.investorId === deposit.investorId &&
        tx.type === 'DEPOSIT' &&
        tx.status === 'PENDING' &&
        !foundTx
      ) {
        foundTx = true;
        return {
          ...tx,
          status: 'REJECTED',
          descriptionEn: `Deposit of Rs. ${deposit.amountPKR.toLocaleString()} DECLINED by Admin (TID: ${deposit.transactionId})`,
          descriptionUr: `Deposit of Rs. ${deposit.amountPKR.toLocaleString()} DECLINED`
        };
      }
      return tx;
    });

    saveDb(db);
    res.json({ success: true, deposit });
  });

  // 7. Submit Withdrawal Request
  app.post('/api/withdrawals', (req, res) => {
    const { amountPKR, paymentMethod, accountDetails, accountTitle, investorId, investorName } = req.body;
    console.log(`[WITHDRAWAL SUBMITTED] New withdrawal of Rs. ${amountPKR} by ${investorName}`);
    const db = loadDb();

    const investor = db.investors.find((i: any) => i.id === investorId);
    if (!investor) {
      return res.status(404).json({ error: 'Investor not found' });
    }

    if (amountPKR > investor.availableBalancePKR) {
      return res.status(400).json({ error: 'Requested amount exceeds available balance' });
    }

    const newWithdrawal = {
      id: `wth_${Date.now()}`,
      investorId: investor.id,
      investorName: investor.name,
      amountPKR: Number(amountPKR),
      paymentMethod,
      accountDetails,
      accountTitle,
      status: 'pending',
      requestedAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };

    // Lock funds in pending withdrawal
    investor.availableBalancePKR -= Number(amountPKR);
    investor.pendingWithdrawalPKR += Number(amountPKR);

    db.withdrawalRequests.unshift(newWithdrawal);
    db.transactions.unshift({
      id: `tx_${Date.now()}`,
      investorId: investor.id,
      type: 'WITHDRAWAL',
      paymentMethod,
      referenceId: newWithdrawal.id,
      amountPKR: Number(amountPKR),
      descriptionEn: `Withdrawal request for Rs. ${Number(amountPKR).toLocaleString()} via ${String(paymentMethod).toUpperCase()} to ${accountTitle} (${accountDetails})`,
      descriptionUr: `Withdrawal request for Rs. ${Number(amountPKR).toLocaleString()} to ${accountTitle}`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'PENDING'
    });

    saveDb(db);
    res.json({ success: true, withdrawal: newWithdrawal });
  });

  // 8. Admin Approve Withdrawal
  app.post('/api/withdrawals/:id/approve', (req, res) => {
    const { id } = req.params;
    const db = loadDb();

    const wth = db.withdrawalRequests.find((w: any) => w.id === id);
    if (!wth) return res.status(404).json({ error: 'Withdrawal not found' });

    wth.status = 'approved';
    wth.processedAt = new Date().toISOString().replace('T', ' ').substring(0, 16);
    wth.referenceId = `PAY-${Math.floor(100000 + Math.random() * 900000)}`;

    db.investors = db.investors.map((inv: any) => {
      if (inv.id === wth.investorId) {
        return {
          ...inv,
          pendingWithdrawalPKR: Math.max(0, inv.pendingWithdrawalPKR - wth.amountPKR)
        };
      }
      return inv;
    });

    // Update pending withdrawal transaction to COMPLETED
    let foundTx = false;
    db.transactions = db.transactions.map((tx: any) => {
      if (
        tx.investorId === wth.investorId &&
        tx.type === 'WITHDRAWAL' &&
        tx.status === 'PENDING' &&
        !foundTx
      ) {
        foundTx = true;
        return {
          ...tx,
          status: 'COMPLETED',
          descriptionEn: `Withdrawal of Rs. ${wth.amountPKR.toLocaleString()} APPROVED & TRANSFERRED via ${String(wth.paymentMethod).toUpperCase()} (Ref: ${wth.referenceId})`,
          descriptionUr: `Withdrawal of Rs. ${wth.amountPKR.toLocaleString()} APPROVED & TRANSFERRED`
        };
      }
      return tx;
    });

    saveDb(db);
    console.log(`[WITHDRAWAL APPROVED] Admin approved withdrawal ${id} for ${wth.investorName} - Rs. ${wth.amountPKR}`);
    res.json({ success: true, withdrawal: wth });
  });

  // 9. Admin Reject Withdrawal (Restores balance)
  app.post('/api/withdrawals/:id/reject', (req, res) => {
    const { id } = req.params;
    const db = loadDb();

    const wth = db.withdrawalRequests.find((w: any) => w.id === id);
    if (!wth) return res.status(404).json({ error: 'Withdrawal not found' });

    wth.status = 'rejected';

    db.investors = db.investors.map((inv: any) => {
      if (inv.id === wth.investorId) {
        return {
          ...inv,
          availableBalancePKR: inv.availableBalancePKR + wth.amountPKR,
          pendingWithdrawalPKR: Math.max(0, inv.pendingWithdrawalPKR - wth.amountPKR)
        };
      }
      return inv;
    });

    // Update pending withdrawal transaction to REJECTED
    let foundTx = false;
    db.transactions = db.transactions.map((tx: any) => {
      if (
        tx.investorId === wth.investorId &&
        tx.type === 'WITHDRAWAL' &&
        tx.status === 'PENDING' &&
        !foundTx
      ) {
        foundTx = true;
        return {
          ...tx,
          status: 'REJECTED',
          descriptionEn: `Withdrawal of Rs. ${wth.amountPKR.toLocaleString()} REJECTED & REFUNDED by Admin`,
          descriptionUr: `Withdrawal of Rs. ${wth.amountPKR.toLocaleString()} REJECTED & REFUNDED`
        };
      }
      return tx;
    });

    saveDb(db);
    res.json({ success: true, withdrawal: wth });
  });

  // 10. Admin Distribute Daily Profit
  app.post('/api/distribute-profit', (req, res) => {
    const { profitRate, strategyName, primaryAsset, marketNotes } = req.body;
    const db = loadDb();

    const todayStr = new Date().toISOString().split('T')[0];
    const nowTimeStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
    let totalDistributed = 0;
    let count = 0;

    db.investors = db.investors.map((inv: any) => {
      if (inv.capitalInvestedPKR > 0 && inv.status === 'active') {
        const profitAmount = Math.round((inv.capitalInvestedPKR * Number(profitRate)) / 100);
        totalDistributed += profitAmount;
        count++;

        db.dailyProfits.unshift({
          id: `dp_${Date.now()}_${inv.id}`,
          investorId: inv.id,
          investorName: inv.name,
          date: todayStr,
          returnPercentage: Number(profitRate),
          amountPKR: profitAmount,
          strategyName: strategyName || 'London & NY Session Alpha',
          tradePair: primaryAsset || 'XAU/USD',
          status: 'credited'
        });

        db.transactions.unshift({
          id: `tx_${Date.now()}_${inv.id}`,
          investorId: inv.id,
          type: 'PROFIT',
          amountPKR: profitAmount,
          descriptionEn: `Daily profit (${profitRate}%) of Rs. ${profitAmount.toLocaleString()} credited`,
          descriptionUr: `Daily profit (${profitRate}%) of Rs. ${profitAmount.toLocaleString()} credited`,
          date: nowTimeStr,
          status: 'COMPLETED'
        });

        return {
          ...inv,
          totalProfitEarnedPKR: inv.totalProfitEarnedPKR + profitAmount,
          availableBalancePKR: inv.availableBalancePKR + profitAmount
        };
      }
      return inv;
    });

    saveDb(db);
    res.json({ success: true, totalDistributedPKR: totalDistributed, investorsCount: count });
  });

  // 11. Reset to initial demo data
  app.post('/api/reset-demo', (req, res) => {
    const initial = getInitialDb();
    saveDb(initial);
    res.json({ success: true, message: 'Database reset to sample state' });
  });

  // Dedicated ZIP Download Route Handler
  const handleZipDownload = (req: express.Request, res: express.Response) => {
    const zipPathInPublic = path.resolve(__dirname, 'public/fasttest-profit-daily.zip');
    const zipPathInDist = path.resolve(__dirname, 'dist/fasttest-profit-daily.zip');
    const zipPathProject = path.resolve(__dirname, 'public/project.zip');

    let targetZip = '';
    if (fs.existsSync(zipPathInPublic)) {
      targetZip = zipPathInPublic;
    } else if (fs.existsSync(zipPathInDist)) {
      targetZip = zipPathInDist;
    } else if (fs.existsSync(zipPathProject)) {
      targetZip = zipPathProject;
    }

    if (targetZip && fs.existsSync(targetZip)) {
      return res.download(targetZip, 'fasttest-profit-daily.zip', (err) => {
        if (err && !res.headersSent) {
          res.status(500).send('Error downloading file');
        }
      });
    } else {
      return res.status(404).send('Zip file is generating, please try again in a few seconds.');
    }
  };

  app.get('/api/download-zip', handleZipDownload);
  app.get('/fasttest-profit-daily.zip', handleZipDownload);
  app.get('/project.zip', handleZipDownload);

  // Vite middlewares for frontend SPA
  if (process.env.NODE_ENV === 'production' && fs.existsSync(path.resolve(__dirname, 'dist'))) {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist/index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false
      },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  }

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`> Full-stack server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
