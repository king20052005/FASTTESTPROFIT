import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { InvestorOverview } from './components/InvestorOverview';
import { InvestmentPlans } from './components/InvestmentPlans';
import { DailyProfitLedger } from './components/DailyProfitLedger';
import { TradingJournal } from './components/TradingJournal';
import { TraderAdminPanel } from './components/TraderAdminPanel';
import { DepositModal } from './components/DepositModal';
import { WithdrawModal } from './components/WithdrawModal';
import { DailyProfitDistributionModal } from './components/DailyProfitDistributionModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { AuthPage } from './components/AuthPage';
import { TelegramSupportButton } from './components/TelegramSupportButton';

const MainContent: React.FC = () => {
  const { isAuthenticated, currentRoleView, activeNavTab, isAdmin, language, t } = useApp();

  if (!isAuthenticated) {
    return <AuthPage />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-amber-400 selection:text-slate-950 pb-6">
      <div>
        <Header />

        <main className="max-w-2xl mx-auto px-3 sm:px-4 py-4">
          {isAdmin && currentRoleView === 'manager' ? (
            <TraderAdminPanel />
          ) : (
            <>
              {activeNavTab === 'dashboard' && <InvestorOverview />}
              {activeNavTab === 'plans' && <InvestmentPlans />}
              {activeNavTab === 'ledger' && <DailyProfitLedger />}
              {activeNavTab === 'trades' && <TradingJournal />}
              {isAdmin && activeNavTab === 'manager' && <TraderAdminPanel />}
            </>
          )}
        </main>
      </div>

      {/* Footer */}
      <footer className="mt-16 border-t border-slate-900 bg-slate-950 py-10 px-4 sm:px-8 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex flex-col sm:flex-row items-center gap-3 text-center sm:text-left">
            <span className="font-bold text-slate-300 text-sm">
              {t('brandName')}
            </span>
            <span className="hidden sm:inline" aria-hidden="true">·</span>
            <span>
              Institutional Portfolio & Daily 24h Profit Management
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-slate-400">
            <span>Automated Daily Payouts</span>
            <span className="text-slate-700">·</span>
            <span>© 2026 {t('brandName')}</span>
          </div>
        </div>
      </footer>

      {/* Global Modals & Indicators */}
      <DepositModal />
      <WithdrawModal />
      <DailyProfitDistributionModal />
      <OfflineIndicator />
      <TelegramSupportButton />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
