import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  TrendingUp,
  ShieldCheck,
  Lock,
  User,
  Phone,
  Eye,
  EyeOff,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Download,
  MessageSquare,
  Smartphone,
  KeyRound,
  RotateCcw,
  Sparkles
} from 'lucide-react';
import { downloadProjectZip } from '../utils/downloadZip';

export const AuthPage: React.FC = () => {
  const { login, register, t } = useApp();
  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');

  // Form states
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Register Form states
  const [registerUsername, setRegisterUsername] = useState('');
  const [registerPhone, setRegisterPhone] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');

  // OTP Verification States
  const [otpChannel, setOtpChannel] = useState<'whatsapp' | 'sms'>('whatsapp');
  const [otpSent, setOtpSent] = useState(false);
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [enteredOtp, setEnteredOtp] = useState('');
  const [isSendingOtp, setIsSendingOtp] = useState(false);

  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!loginUsername.trim() || !loginPassword.trim()) {
      setErrorMessage('Please enter both username and password.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      const res = login(loginUsername.trim(), loginPassword);
      setIsLoading(false);
      if (!res.success) {
        setErrorMessage(res.error || 'Invalid username or password.');
      }
    }, 400);
  };

  // Helper to format clean Pakistan mobile number
  const formatPhoneForWa = (rawPhone: string) => {
    let digits = rawPhone.replace(/\D/g, '');
    if (digits.startsWith('0')) {
      digits = '92' + digits.substring(1);
    } else if (!digits.startsWith('92') && digits.length === 10) {
      digits = '92' + digits;
    }
    return digits;
  };

  // Step 1: Send OTP to WhatsApp or SIM SMS (Real Launcher)
  const handleRequestOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!registerUsername.trim()) {
      setErrorMessage('Please enter your username.');
      return;
    }

    if (!registerPhone.trim() || registerPhone.trim().length < 10) {
      setErrorMessage('Please enter a valid 10 to 11 digit mobile number.');
      return;
    }

    if (registerPassword.length < 4) {
      setErrorMessage('Password must be at least 4 characters long.');
      return;
    }

    setIsSendingOtp(true);
    setTimeout(() => {
      // Generate 6-digit OTP code
      const code = Math.floor(100000 + Math.random() * 900000).toString();
      const cleanPhone = formatPhoneForWa(registerPhone);
      setGeneratedOtp(code);
      setOtpSent(true);
      setIsSendingOtp(false);

      if (otpChannel === 'whatsapp') {
        // Real WhatsApp Direct Open Link
        const waText = encodeURIComponent(
          `FASTTEST PROFIT Verification Code: ${code}\nUser: ${registerUsername.trim()}\nMobile: ${registerPhone.trim()}`
        );
        const waUrl = `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${waText}`;
        window.open(waUrl, '_blank');

        setSuccessMessage(
          `💬 WhatsApp app opened for ${registerPhone.trim()} with Code (${code}). Check WhatsApp and enter code below.`
        );
      } else {
        // Real SIM SMS Direct Link
        const smsUrl = `sms:${cleanPhone}?body=${encodeURIComponent(
          `FASTTEST Verification Code: ${code}`
        )}`;
        window.location.href = smsUrl;

        setSuccessMessage(
          `📱 Device SMS opened for ${registerPhone.trim()} with Code (${code}). Enter code below to complete registration.`
        );
      }
    }, 600);
  };

  // Step 2: Verify OTP and Register Account
  const handleVerifyAndRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!enteredOtp.trim()) {
      setErrorMessage('Please enter the 6-digit OTP code sent to your number.');
      return;
    }

    if (enteredOtp.trim() !== generatedOtp) {
      setErrorMessage('Incorrect OTP code! Please check your SMS/WhatsApp and re-enter.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      const res = register(registerUsername.trim(), registerPhone.trim(), registerPassword);
      setIsLoading(false);
      if (res.success) {
        setSuccessMessage('✓ Mobile Number Verified & Account Created! Logging you in...');
      } else {
        setErrorMessage(res.error || 'Registration failed. Try a different username.');
      }
    }, 400);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-between selection:bg-amber-400 selection:text-slate-950 font-sans">
      {/* Top Simple Brand Bar (Straight Line) */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
            <TrendingUp className="w-4 h-4 stroke-[2.5]" />
          </div>
          <span className="font-bold text-white text-sm sm:text-base tracking-tight">
            {t('brandName')}
          </span>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-slate-400 bg-slate-950 px-2.5 py-1 rounded-full border border-slate-800">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span>Live 24h Payouts</span>
        </div>
      </div>

      {/* Main Authentication (Clean Flat Card) */}
      <div className="flex-1 flex items-center justify-center p-4 my-auto">
        <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 space-y-4">
          {/* Header */}
          <div className="text-center space-y-1">
            <h1 className="text-xl font-black text-white">
              {activeTab === 'login' ? 'Sign In to Account' : 'Create Investor Account'}
            </h1>
            <p className="text-xs text-slate-400">
              3,000 PKR to 1,00,000 PKR Daily Profit Portfolio
            </p>
          </div>

          {/* Straight Tabs: Sign In / Register */}
          <div className="grid grid-cols-2 gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              type="button"
              onClick={() => {
                setActiveTab('login');
                setErrorMessage(null);
                setSuccessMessage(null);
              }}
              className={`py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                activeTab === 'login'
                  ? 'bg-amber-400 text-slate-950'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('register');
                setErrorMessage(null);
                setSuccessMessage(null);
                setOtpSent(false);
              }}
              className={`py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                activeTab === 'register'
                  ? 'bg-amber-400 text-slate-950'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Register
            </button>
          </div>

          {/* Feedback messages */}
          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-950/70 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs flex items-start gap-2 shadow-md">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span className="leading-snug">{successMessage}</span>
            </div>
          )}

          {/* LOGIN FORM */}
          {activeTab === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Username or Mobile Number
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={loginUsername}
                    onChange={(e) => setLoginUsername(e.target.value)}
                    placeholder="Enter your username"
                    className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                    autoComplete="username"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-9 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                    autoComplete="current-password"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500 hover:text-slate-300 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50 mt-1"
              >
                <span>{isLoading ? 'Signing In...' : 'Sign In'}</span>
                <ArrowRight className="w-4 h-4 stroke-[2.5]" />
              </button>
            </form>
          )}

          {/* REGISTER FORM (DIRECT & INSTANT SIGNUP - NO OTP) */}
          {activeTab === 'register' && (
            <form onSubmit={(e) => {
              e.preventDefault();
              setErrorMessage(null);
              setSuccessMessage(null);

              if (!registerUsername.trim()) {
                setErrorMessage('Please enter a username.');
                return;
              }
              if (!registerPhone.trim()) {
                setErrorMessage('Please enter a mobile/WhatsApp number.');
                return;
              }
              if (registerPassword.length < 4) {
                setErrorMessage('Password must be at least 4 characters long.');
                return;
              }

              setIsLoading(true);
              setTimeout(() => {
                const res = register(
                  registerUsername.trim(),
                  registerPhone.trim(),
                  registerPassword
                );
                setIsLoading(false);
                if (res.success) {
                  setSuccessMessage('✓ Account created successfully! Logging you in...');
                } else {
                  setErrorMessage(res.error || 'Registration failed. Username may already be taken.');
                }
              }, 400);
            }} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Choose Username *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={registerUsername}
                    onChange={(e) => setRegisterUsername(e.target.value)}
                    placeholder="e.g. user786"
                    className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Mobile / WhatsApp Number *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                    <Phone className="w-4 h-4" />
                  </div>
                  <input
                    type="tel"
                    value={registerPhone}
                    onChange={(e) => setRegisterPhone(e.target.value)}
                    placeholder="e.g. 03001234567"
                    className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                    required
                  />
                </div>
              </div>

              {/* Single Password Field Only */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Password *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={registerPassword}
                    onChange={(e) => setRegisterPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-9 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500 hover:text-slate-300 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50 shadow-md"
                >
                  <span>{isLoading ? 'Creating Account...' : 'Create Account & Start'}</span>
                  <ArrowRight className="w-4 h-4 stroke-[2.5]" />
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

      {/* Auth Footer with Download ZIP exclusively on Login page bottom */}
      <footer className="border-t border-slate-900 bg-slate-900/80 py-4 px-4 text-center text-xs text-slate-400 space-y-2">
        <div className="flex flex-wrap items-center justify-center gap-3">
          <span className="flex items-center gap-1.5 text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Encrypted Ledger System</span>
          </span>
          <span className="text-slate-700">·</span>
          <span>© 2026 {t('brandName')}</span>
        </div>

        {/* Download ZIP button at bottom */}
        <div className="pt-1">
          <a
            href="/api/download-zip"
            download="fasttest-profit-daily.zip"
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs sm:text-sm rounded-xl shadow-xl transition-all inline-flex items-center gap-2 cursor-pointer border border-amber-300/50"
            title="Download Project Source Code ZIP File"
          >
            <Download className="w-4 h-4 stroke-[2.5]" />
            <span>Download Project ZIP</span>
          </a>
        </div>
      </footer>
    </div>
  );
};
