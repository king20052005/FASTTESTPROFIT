import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Check, BarChart3, TrendingUp, ShieldAlert } from 'lucide-react';

export const DailyProfitDistributionModal: React.FC = () => {
  const {
    isDistributeModalOpen,
    setIsDistributeModalOpen,
    allInvestors,
    distributeDailyProfit,
    formatMoney,
    language,
    t
  } = useApp();

  const [profitRate, setProfitRate] = useState<number>(2.10);
  const [strategyName, setStrategyName] = useState<string>('Gold Scalp London & NY Session');
  const [primaryAsset, setPrimaryAsset] = useState<string>('XAU/USD (Gold)');
  const [marketNotes, setMarketNotes] = useState<string>(
    'Disciplined execution on London liquidity grab. Take profit hit cleanly with zero slippage.'
  );
  const [result, setResult] = useState<{ totalDistributedPKR: number; investorsCount: number } | null>(null);

  if (!isDistributeModalOpen) return null;

  const activeInvestors = allInvestors.filter((i) => i.capitalInvestedPKR > 0 && i.status === 'active');
  const totalAUM = activeInvestors.reduce((acc, curr) => acc + curr.capitalInvestedPKR, 0);
  const projectedTotalDistribution = Math.round((totalAUM * profitRate) / 100);

  const handleExecute = (e: React.FormEvent) => {
    e.preventDefault();
    if (profitRate <= 0) {
      alert('Please enter a valid profit percentage greater than 0.');
      return;
    }

    const res = distributeDailyProfit(profitRate, strategyName, primaryAsset, marketNotes);
    setResult(res);

    setTimeout(() => {
      setResult(null);
      setIsDistributeModalOpen(false);
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-7 my-8">
        <button
          onClick={() => {
            setIsDistributeModalOpen(false);
            setResult(null);
          }}
          className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {result ? (
          <div className="py-10 text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/40">
              <Check className="w-8 h-8 stroke-[3]" />
            </div>
            <h3 className="text-xl font-bold text-white">
              {t('distributionSuccess')}
            </h3>
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 max-w-xs mx-auto space-y-2">
              <div className="flex justify-between text-xs text-slate-400">
                <span>{language === 'ur' ? 'شرح منافع:' : 'Profit Rate:'}</span>
                <span className="font-bold text-emerald-400 font-mono">+{profitRate}%</span>
              </div>
              <div className="flex justify-between text-xs text-slate-400">
                <span>{language === 'ur' ? 'کل تقسیم شدہ رقم:' : 'Total Credited:'}</span>
                <span className="font-bold text-white font-mono">{formatMoney(result.totalDistributedPKR)}</span>
              </div>
              <div className="flex justify-between text-xs text-slate-400">
                <span>{language === 'ur' ? 'مستفید انویسٹرز:' : 'Investors Credited:'}</span>
                <span className="font-bold text-white font-mono">{result.investorsCount} Accounts</span>
              </div>
            </div>
          </div>
        ) : (
          <form onSubmit={handleExecute} className="space-y-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <BarChart3 className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg sm:text-xl font-bold text-white">
                  {t('distributeModalTitle')}
                </h2>
                <p className="text-xs text-slate-400">
                  {t('distributeModalSubtitle')}
                </p>
              </div>
            </div>

            {/* AUM Preview Banner */}
            <div className="grid grid-cols-3 gap-3 bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-center">
              <div>
                <span className="text-[11px] text-slate-400 block">{language === 'ur' ? 'فعال کلائنٹس' : 'Active Clients'}</span>
                <span className="text-base font-bold font-mono text-white tabular-nums">
                  {activeInvestors.length}
                </span>
              </div>
              <div>
                <span className="text-[11px] text-slate-400 block">{language === 'ur' ? 'منظم فنڈ (AUM)' : 'Active Capital'}</span>
                <span className="text-base font-bold font-mono text-blue-400 tabular-nums">
                  {formatMoney(totalAUM)}
                </span>
              </div>
              <div>
                <span className="text-[11px] text-slate-400 block">{language === 'ur' ? 'آج کی کل تقسیم' : 'Est. Distribution'}</span>
                <span className="text-base font-bold font-mono text-emerald-400 tabular-nums">
                  +{formatMoney(projectedTotalDistribution)}
                </span>
              </div>
            </div>

            {/* Profit percentage input */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <label className="font-semibold text-slate-300">
                  {t('todayProfitPercentage')}
                </label>
                <span className="text-emerald-400 font-mono font-medium">
                  {language === 'ur' ? 'عام روزانہ حد: 1.2% - 3.5%' : 'Typical range: 1.2% - 3.5%'}
                </span>
              </div>
              <div className="relative">
                <input
                  type="number"
                  min="0.1"
                  max="10"
                  step="0.05"
                  required
                  value={profitRate}
                  onChange={(e) => setProfitRate(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-lg font-mono font-bold text-emerald-400 focus:outline-none focus:border-amber-400"
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 font-mono font-bold">%</span>
              </div>

              {/* Quick Preset Buttons */}
              <div className="flex items-center gap-1.5 mt-2">
                {[1.5, 1.85, 2.1, 2.4, 2.8].map((rate) => (
                  <button
                    key={rate}
                    type="button"
                    onClick={() => setProfitRate(rate)}
                    className={`px-2.5 py-1 rounded text-[11px] font-mono transition-colors ${
                      profitRate === rate
                        ? 'bg-emerald-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    +{rate}%
                  </button>
                ))}
              </div>
            </div>

            {/* Asset & Strategy */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('primaryAssetTraded')}
                </label>
                <select
                  value={primaryAsset}
                  onChange={(e) => setPrimaryAsset(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="XAU/USD (Gold)">XAU/USD (Gold Bullion)</option>
                  <option value="EUR/USD">EUR/USD (Forex Major)</option>
                  <option value="GBP/JPY">GBP/JPY (Dragon Scalp)</option>
                  <option value="USOIL (Crude)">USOIL (Crude Oil)</option>
                  <option value="BTC/USDT">BTC/USDT (Crypto Breakout)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('tradingStrategyUsed')}
                </label>
                <input
                  type="text"
                  value={strategyName}
                  onChange={(e) => setStrategyName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            {/* Notes for clients */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {t('marketNotes')}
              </label>
              <textarea
                rows={2}
                value={marketNotes}
                onChange={(e) => setMarketNotes(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg text-xs text-amber-300/90 flex items-start gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
              <span>
                {language === 'ur'
                  ? 'یہ بٹن دبانے سے 100 روپے سے 1 لاکھ روپے تک انویسٹ کرنے والے تمام فعال کلائنٹس کو ان کے سرمائے کے تناسب سے آج کا منافع کریڈٹ ہو جائے گا۔'
                  : 'Clicking execute will credit today’s daily profit to all active investors based on their invested capital.'}
              </span>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-emerald-500 to-emerald-400 hover:from-emerald-400 hover:to-emerald-300 text-slate-950 font-bold text-xs sm:text-sm rounded-lg shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <TrendingUp className="w-4 h-4 stroke-[2.5]" />
              <span>{t('executeDistribution')}</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
