import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Calendar,
  Search,
  Filter,
  TrendingUp,
  CheckCircle2,
  Clock,
  XCircle,
  ArrowDownLeft,
  ArrowUpRight,
  Smartphone,
  CreditCard,
  Globe,
  Wallet,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { Transaction } from '../types';

export const DailyProfitLedger: React.FC = () => {
  const {
    dailyProfits,
    transactions,
    currentUser,
    formatMoney,
    setIsDepositModalOpen,
    setIsWithdrawModalOpen,
    language,
    t
  } = useApp();

  const [activeTab, setActiveTab] = useState<'transactions' | 'profits'>('transactions');
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'ALL' | 'PENDING' | 'DEPOSIT' | 'WITHDRAWAL' | 'PROFIT'>('ALL');
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);

  const safeUser = currentUser || {
    id: '',
    name: '',
    availableBalancePKR: 0,
    capitalInvestedPKR: 0
  };

  // Filter for current user's data with robust ID and name matching
  const userTransactions = transactions.filter(
    (tx) => tx.investorId === safeUser.id || (safeUser.name && tx.descriptionEn.toLowerCase().includes(safeUser.name.toLowerCase()))
  );
  const userProfits = dailyProfits.filter((dp) => dp.investorId === safeUser.id);

  const filteredTransactions = userTransactions.filter((tx) => {
    const matchesSearch =
      tx.descriptionEn.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (tx.referenceId && tx.referenceId.toLowerCase().includes(searchTerm.toLowerCase())) ||
      tx.date.includes(searchTerm);

    if (!matchesSearch) return false;

    if (typeFilter === 'ALL') return true;
    if (typeFilter === 'PENDING') return tx.status === 'PENDING';
    return tx.type === typeFilter;
  });

  const filteredProfits = userProfits.filter(
    (p) =>
      p.strategyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.tradePair.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.date.includes(searchTerm)
  );

  const totalEarned = userProfits.reduce((acc, curr) => acc + curr.amountPKR, 0);
  const totalDeposited = userTransactions
    .filter((tx) => tx.type === 'DEPOSIT' && tx.status === 'COMPLETED')
    .reduce((acc, curr) => acc + curr.amountPKR, 0);
  const pendingDepositsSum = userTransactions
    .filter((tx) => tx.type === 'DEPOSIT' && tx.status === 'PENDING')
    .reduce((acc, curr) => acc + curr.amountPKR, 0);
  const pendingWithdrawalsSum = userTransactions
    .filter((tx) => tx.type === 'WITHDRAWAL' && tx.status === 'PENDING')
    .reduce((acc, curr) => acc + curr.amountPKR, 0);

  const getTxMethodInfo = (tx: Transaction) => {
    if (tx.type === 'PROFIT') {
      return {
        label: 'Daily Profit',
        icon: TrendingUp,
        badgeBg: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40',
        logoText: '24H ROI',
        accentColor: 'text-emerald-400'
      };
    }

    const desc = (tx.descriptionEn || '').toLowerCase();
    const method = tx.paymentMethod;

    if (method === 'easypaisa' || desc.includes('easypaisa')) {
      return {
        label: 'EasyPaisa',
        icon: Smartphone,
        badgeBg: 'bg-emerald-950 text-emerald-300 border-emerald-500/40',
        logoText: 'EasyPaisa',
        accentColor: 'text-emerald-400'
      };
    }
    if (method === 'jazzcash' || desc.includes('jazzcash')) {
      return {
        label: 'JazzCash',
        icon: Smartphone,
        badgeBg: 'bg-amber-950 text-amber-300 border-amber-500/40',
        logoText: 'JazzCash',
        accentColor: 'text-amber-400'
      };
    }
    if (method === 'paytm' || desc.includes('paytm') || desc.includes('upi')) {
      return {
        label: 'Paytm / UPI',
        icon: CreditCard,
        badgeBg: 'bg-sky-950 text-sky-300 border-sky-500/40',
        logoText: 'Paytm UPI',
        accentColor: 'text-sky-400'
      };
    }
    if (method === 'paypal' || desc.includes('paypal')) {
      return {
        label: 'PayPal',
        icon: Globe,
        badgeBg: 'bg-indigo-950 text-indigo-300 border-indigo-500/40',
        logoText: 'PayPal',
        accentColor: 'text-indigo-400'
      };
    }

    return {
      label: tx.type === 'DEPOSIT' ? 'Deposit' : 'Withdrawal',
      icon: tx.type === 'DEPOSIT' ? ArrowDownLeft : ArrowUpRight,
      badgeBg: 'bg-slate-800 text-slate-300 border-slate-700',
      logoText: tx.type,
      accentColor: tx.type === 'DEPOSIT' ? 'text-blue-400' : 'text-rose-400'
    };
  };

  const handleExportCSV = () => {
    const headers = ['Date', 'Type', 'Amount (PKR)', 'Status', 'Description'];
    const rows = userTransactions.map((tx) => [
      tx.date,
      tx.type,
      tx.amountPKR,
      tx.status,
      `"${tx.descriptionEn.replace(/"/g, '""')}"`
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `account_transactions_${safeUser.id || 'export'}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4 font-sans">
      {/* LINE 1: Straight WhatsApp-Style Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 sm:p-4 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white leading-tight">
              Transaction History
            </h2>
            <p className="text-[11px] text-slate-400">
              Straight financial record · Live Sync
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setIsDepositModalOpen(true)}
            className="px-2.5 py-1.5 bg-emerald-500 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-1 cursor-pointer"
          >
            <ArrowDownLeft className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>Deposit</span>
          </button>
          <button
            onClick={() => setIsWithdrawModalOpen(true)}
            className="px-2.5 py-1.5 bg-slate-800 text-slate-200 border border-slate-700 font-bold text-xs rounded-lg flex items-center gap-1 cursor-pointer"
          >
            <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400 stroke-[2.5]" />
            <span>Cashout</span>
          </button>
        </div>
      </div>

      {/* LINE 2: Straight Summary Numbers Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
        <div className="border-r border-slate-800/80 last:border-r-0 pr-1">
          <span className="text-[10px] text-slate-400 block">Available</span>
          <span className="text-xs sm:text-sm font-bold font-mono text-white">
            {formatMoney(safeUser.availableBalancePKR)}
          </span>
        </div>
        <div className="border-r border-slate-800/80 last:border-r-0 pr-1">
          <span className="text-[10px] text-slate-400 block">Active Capital</span>
          <span className="text-xs sm:text-sm font-bold font-mono text-blue-400">
            {formatMoney(safeUser.capitalInvestedPKR)}
          </span>
        </div>
        <div className="border-r border-slate-800/80 last:border-r-0 pr-1">
          <span className="text-[10px] text-slate-400 block">Total Profit</span>
          <span className="text-xs sm:text-sm font-bold font-mono text-emerald-400">
            +{formatMoney(totalEarned)}
          </span>
        </div>
        <div>
          <span className="text-[10px] text-amber-400 block">Pending</span>
          <span className="text-xs sm:text-sm font-bold font-mono text-amber-300">
            {formatMoney(pendingDepositsSum + pendingWithdrawalsSum)}
          </span>
        </div>
      </div>

      {/* LINE 3: Straight Segmented Tab Switcher */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-1 grid grid-cols-2 gap-1 text-xs font-bold">
        <button
          onClick={() => setActiveTab('transactions')}
          className={`py-2 rounded-lg text-center transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'transactions'
              ? 'bg-amber-400 text-slate-950 font-black'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Wallet className="w-3.5 h-3.5" />
          <span>All Transactions ({userTransactions.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('profits')}
          className={`py-2 rounded-lg text-center transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'profits'
              ? 'bg-amber-400 text-slate-950 font-black'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5" />
          <span>24h Daily Profits ({userProfits.length})</span>
        </button>
      </div>

      {/* LINE 4: Search & Quick Filters */}
      <div className="space-y-2">
        <div className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 flex items-center gap-2">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            placeholder={
              activeTab === 'transactions'
                ? 'Search TID, EasyPaisa, Paytm, PayPal...'
                : 'Search strategy, pair, or date...'
            }
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-transparent text-xs text-white placeholder-slate-500 focus:outline-none"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="text-[11px] text-slate-400 hover:text-white cursor-pointer"
            >
              Clear
            </button>
          )}
        </div>

        {activeTab === 'transactions' && (
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px]">
            {(['ALL', 'PENDING', 'DEPOSIT', 'WITHDRAWAL', 'PROFIT'] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => setTypeFilter(mode)}
                className={`px-3 py-1 rounded-full border transition-all whitespace-nowrap cursor-pointer ${
                  typeFilter === mode
                    ? 'bg-slate-100 text-slate-950 font-bold border-slate-100'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                {mode === 'ALL'
                  ? 'All'
                  : mode === 'PENDING'
                  ? `Pending (${userTransactions.filter(t => t.status === 'PENDING').length})`
                  : mode === 'DEPOSIT'
                  ? 'Deposits'
                  : mode === 'WITHDRAWAL'
                  ? 'Cashouts'
                  : 'Profits'}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* LINE 5: WhatsApp-Style Vertical Rows (Straight Down) */}
      {activeTab === 'transactions' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl divide-y divide-slate-800/80 overflow-hidden">
          {filteredTransactions.length === 0 ? (
            <div className="py-12 text-center text-slate-500 text-xs space-y-2">
              <Wallet className="w-8 h-8 text-slate-600 mx-auto" />
              <p>No transactions match your search or filter.</p>
              <button
                onClick={() => setIsDepositModalOpen(true)}
                className="mt-1 px-3 py-1.5 bg-amber-400 text-slate-950 rounded-lg text-xs font-bold"
              >
                Make a Deposit
              </button>
            </div>
          ) : (
            filteredTransactions.map((tx) => {
              const info = getTxMethodInfo(tx);
              const MethodIcon = info.icon;
              const isPending = tx.status === 'PENDING';
              const isCompleted = tx.status === 'COMPLETED';
              const isNegative = tx.type === 'WITHDRAWAL';

              return (
                <div
                  key={tx.id}
                  onClick={() => setSelectedTx(tx)}
                  className="p-3 sm:p-3.5 hover:bg-slate-800/40 transition-colors flex items-center justify-between gap-3 cursor-pointer"
                >
                  {/* Left: Avatar with Method Icon */}
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`w-10 h-10 rounded-full border flex items-center justify-center shrink-0 ${info.badgeBg}`}>
                      <MethodIcon className="w-5 h-5 stroke-[2.2]" />
                    </div>

                    {/* Middle: Title, TID, Date (Linear WhatsApp Row) */}
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-white text-xs sm:text-sm truncate">
                          {info.label} {tx.type === 'PROFIT' ? '' : tx.type === 'DEPOSIT' ? 'Deposit' : 'Withdrawal'}
                        </span>
                        {isPending && (
                          <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-amber-950 text-amber-300 border border-amber-500/50">
                            Pending
                          </span>
                        )}
                      </div>

                      <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5 font-mono truncate">
                        <span>{tx.date}</span>
                        {tx.referenceId && (
                          <>
                            <span>·</span>
                            <span className="text-amber-400/90 truncate">TID: {tx.referenceId}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Right: Amount & Status Badge */}
                  <div className="text-right shrink-0 flex flex-col items-end">
                    <span
                      className={`text-xs sm:text-sm font-bold font-mono tabular-nums ${
                        isNegative ? 'text-rose-400' : 'text-emerald-400'
                      }`}
                    >
                      {isNegative ? '-' : '+'}
                      {formatMoney(tx.amountPKR)}
                    </span>

                    <div className="mt-1">
                      {isPending ? (
                        <span className="inline-flex items-center gap-1 text-[10px] text-amber-300 bg-amber-950/70 border border-amber-500/40 px-2 py-0.5 rounded-full font-semibold">
                          <Clock className="w-2.5 h-2.5 animate-spin" />
                          <span>Waiting Admin</span>
                        </span>
                      ) : isCompleted ? (
                        <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-950/70 border border-emerald-500/40 px-2 py-0.5 rounded-full font-semibold">
                          <CheckCircle2 className="w-2.5 h-2.5" />
                          <span>Confirmed</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[10px] text-rose-400 bg-rose-950/70 border border-rose-500/40 px-2 py-0.5 rounded-full font-semibold">
                          <XCircle className="w-2.5 h-2.5" />
                          <span>Declined</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* LINE 5 (Profits View): WhatsApp-Style Straight Profits List */}
      {activeTab === 'profits' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl divide-y divide-slate-800/80 overflow-hidden">
          {filteredProfits.length === 0 ? (
            <div className="py-12 text-center text-slate-500 text-xs">
              No daily profit distributions recorded yet.
            </div>
          ) : (
            filteredProfits.map((profit) => (
              <div
                key={profit.id}
                className="p-3 sm:p-3.5 hover:bg-slate-800/40 transition-colors flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
                    <TrendingUp className="w-5 h-5 stroke-[2.2]" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-xs sm:text-sm">
                        {profit.strategyName}
                      </span>
                      <span className="font-mono text-amber-400 bg-amber-400/10 px-1.5 py-0.2 rounded text-[10px] font-bold">
                        {profit.tradePair}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 font-mono mt-0.5 block">
                      {profit.date} · 24-Hour Cycle
                    </span>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-xs sm:text-sm font-bold font-mono text-emerald-400 tabular-nums block">
                    +{formatMoney(profit.amountPKR)}
                  </span>
                  <span className="text-[10px] font-bold text-emerald-300 font-mono">
                    +{profit.returnPercentage}% Daily
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Detail Modal if clicked */}
      {selectedTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-sm">
                Transaction Receipt
              </h3>
              <button
                onClick={() => setSelectedTx(null)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded bg-slate-800 cursor-pointer"
              >
                Close
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Status</span>
                <span className={`font-bold ${selectedTx.status === 'PENDING' ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {selectedTx.status}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Amount</span>
                <span className="font-mono font-bold text-white">
                  {formatMoney(selectedTx.amountPKR)}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Date</span>
                <span className="font-mono text-slate-300">{selectedTx.date}</span>
              </div>
              {selectedTx.referenceId && (
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">TID / Ref</span>
                  <span className="font-mono text-amber-300">{selectedTx.referenceId}</span>
                </div>
              )}
              <div className="py-1">
                <span className="text-slate-400 block mb-1">Details</span>
                <p className="text-slate-200 bg-slate-950 p-2.5 rounded-lg text-xs leading-relaxed font-mono">
                  {selectedTx.descriptionEn}
                </p>
              </div>
            </div>

            <button
              onClick={() => setSelectedTx(null)}
              className="w-full py-2 bg-amber-400 text-slate-950 font-bold text-xs rounded-xl"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
