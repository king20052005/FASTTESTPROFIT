import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { OFFICIAL_PAYMENT_ACCOUNTS } from '../data/mockData';
import { X, Copy, Check, ArrowRight, Smartphone, Globe, CreditCard } from 'lucide-react';
import { DepositRequest } from '../types';

export const ALLOWED_DEPOSIT_AMOUNTS = [
  1000,
  3000,
  7000,
  10000,
  15000,
  25000,
  45000,
  50000,
  100000
];

export const DepositModal: React.FC = () => {
  const {
    isDepositModalOpen,
    setIsDepositModalOpen,
    selectedPlanForDeposit,
    setSelectedPlanForDeposit,
    plans,
    currentUser,
    submitDepositRequest,
    formatMoney,
    t
  } = useApp();

  const [planId, setPlanId] = useState<string>(selectedPlanForDeposit?.id || plans[0]?.id || 'plan_1k');
  const [amountPKR, setAmountPKR] = useState<number>(1000);
  const [paymentMethod, setPaymentMethod] = useState<DepositRequest['paymentMethod']>('easypaisa');
  const [senderAccount, setSenderAccount] = useState<string>(currentUser?.phone || '');
  const [trxId, setTrxId] = useState<string>('');
  const [proofNote, setProofNote] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [submitted, setSubmitted] = useState<boolean>(false);

  useEffect(() => {
    if (selectedPlanForDeposit) {
      setPlanId(selectedPlanForDeposit.id);
      // Pick closest allowed amount
      const closest = ALLOWED_DEPOSIT_AMOUNTS.find((a) => a >= selectedPlanForDeposit.minDepositPKR) || 1000;
      setAmountPKR(closest);
    }
  }, [selectedPlanForDeposit]);

  useEffect(() => {
    if (currentUser?.phone) {
      setSenderAccount(currentUser.phone);
    }
  }, [currentUser]);

  if (!isDepositModalOpen) return null;

  const activeAccount = OFFICIAL_PAYMENT_ACCOUNTS[paymentMethod];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentUser) {
      alert('Please log in to submit a deposit.');
      return;
    }

    if (!ALLOWED_DEPOSIT_AMOUNTS.includes(amountPKR)) {
      alert('Please select an authorized deposit amount: 1,000, 3,000, 7,000, 10,000, 15,000, 25,000, 45,000, 50,000, or 100,000 PKR.');
      return;
    }

    if (!trxId.trim()) {
      alert('Please enter your Transaction ID / UPI Reference / Order ID.');
      return;
    }

    if (!senderAccount.trim()) {
      alert('Please enter your sender account number.');
      return;
    }

    submitDepositRequest(planId, amountPKR, paymentMethod, senderAccount, trxId, proofNote);
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-7 my-8">
        {/* Close Button */}
        <button
          onClick={() => {
            setIsDepositModalOpen(false);
            setSelectedPlanForDeposit(null);
            setSubmitted(false);
          }}
          className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="py-8 text-center space-y-4">
            <div className="w-14 h-14 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/40">
              <Check className="w-7 h-7 stroke-[3]" />
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-white">
              Deposit Slip Submitted!
            </h3>
            <p className="text-xs text-slate-300 max-w-sm mx-auto leading-relaxed">
              Your deposit of <strong className="text-amber-400">Rs. {amountPKR.toLocaleString()}</strong> via <strong className="text-white">{activeAccount.network}</strong> (TID: <span className="font-mono text-emerald-400">{trxId}</span>) has been recorded in the system.
            </p>
            <div className="bg-emerald-950/60 border border-emerald-500/40 p-2.5 rounded-xl text-emerald-300 text-xs text-left max-w-sm mx-auto flex items-start gap-2">
              <span className="font-bold text-emerald-400">⚡</span>
              <span>
                As soon as Admin approves this slip, your <strong>First Day Profit</strong> will credit immediately into your available balance (withdrawable), and your real 24-hour automatic payout countdown will begin!
              </span>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-left text-xs space-y-1.5 max-w-sm mx-auto font-mono">
              <div className="flex justify-between text-slate-400">
                <span>Amount:</span>
                <span className="text-white font-bold">Rs. {amountPKR.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Gateway:</span>
                <span className="text-amber-400">{activeAccount.network}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>TID / Order Ref:</span>
                <span className="text-emerald-400 break-all">{trxId}</span>
              </div>
            </div>

            <div className="pt-2 flex flex-col gap-2 max-w-sm mx-auto">
              {/* Send Slip to Admin on Telegram */}
              <a
                href={`https://t.me/FASTTEST_ADMIN?text=${encodeURIComponent(
                  `Hello Admin, I have submitted a deposit on FASTTEST PROFIT DAILY:\n\n👤 Investor: ${currentUser?.name || 'Unknown'}\n💰 Amount: Rs. ${amountPKR.toLocaleString()}\n💳 Method: ${activeAccount.network}\n📱 Sender: ${senderAccount}\n🔢 TID: ${trxId}\n\nPlease verify and approve my deposit to credit my balance.`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-4 bg-[#229ED9] hover:bg-[#1fa0de] text-white font-bold text-xs rounded-xl shadow-lg shadow-sky-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <span>Send Deposit Slip to Admin on Telegram (@FASTTEST_ADMIN)</span>
              </a>

              <button
                type="button"
                onClick={() => {
                  setSubmitted(false);
                  setIsDepositModalOpen(false);
                  setSelectedPlanForDeposit(null);
                  setTrxId('');
                }}
                className="w-full py-2 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                Done / Back to Dashboard
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-white">
                Deposit Capital (Rs. 1,000 – Rs. 1,00,000)
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Select your authorized deposit tier (from Rs. 1,000 to Rs. 1,00,000) and transfer via EasyPaisa, Paytm or PayPal.
              </p>
            </div>

            {/* Plan Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Target Investment Plan
              </label>
              <select
                value={planId}
                onChange={(e) => setPlanId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
              >
                {plans.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.nameEn} · {p.dailyRoiMin}% Daily
                  </option>
                ))}
              </select>
            </div>

            {/* Exact 9 Authorized Deposit Amounts */}
            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <label className="font-semibold text-slate-300">
                  Select Deposit Amount *
                </label>
                <span className="text-emerald-400 font-mono font-bold text-sm tabular-nums">
                  Rs. {amountPKR.toLocaleString()}
                </span>
              </div>

              {/* 9 Amount Selection Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {ALLOWED_DEPOSIT_AMOUNTS.map((amt) => {
                  const isSelected = amountPKR === amt;
                  const dailyProfitText =
                    amt === 1000 ? 'Rs. 70/day (7%)' :
                    amt === 3000 ? 'Rs. 300/day (10%)' :
                    amt === 7000 ? 'Rs. 700/day (10%)' :
                    amt === 10000 ? 'Rs. 1,500/day (15%)' :
                    amt === 15000 ? 'Rs. 3,000/day (20%)' :
                    amt === 25000 ? 'Rs. 5,000/day (20%)' :
                    amt === 45000 ? 'Rs. 9,000/day (20%)' :
                    amt === 50000 ? 'Rs. 10,000/day (20%)' :
                    'Rs. 20,000/day (20%)';

                  return (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setAmountPKR(amt)}
                      className={`py-2.5 px-2 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center ${
                        isSelected
                          ? 'bg-amber-400 border-amber-300 text-slate-950 font-black shadow-lg shadow-amber-400/20 scale-[1.02] ring-2 ring-amber-400/50'
                          : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-800/60'
                      }`}
                    >
                      <span className={`font-mono text-sm font-bold ${isSelected ? 'text-slate-950' : 'text-white'}`}>
                        Rs. {amt.toLocaleString()}
                      </span>
                      <span className={`text-[10px] font-semibold tracking-tight ${isSelected ? 'text-slate-900 font-bold' : 'text-emerald-400'}`}>
                        +{dailyProfitText}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Payment Method Selector (EasyPaisa, Paytm, PayPal) */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Select Deposit Gateway
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                {/* EasyPaisa (Pakistan) */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('easypaisa')}
                  className={`p-2.5 sm:p-3 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    paymentMethod === 'easypaisa'
                      ? 'bg-emerald-950/60 border-emerald-500 shadow-md shadow-emerald-500/10 ring-1 ring-emerald-500/30 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="w-7 h-7 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center shrink-0 mb-2">
                    <Smartphone className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div>
                    <span className="block font-bold text-white text-xs">EasyPaisa</span>
                    <span className="text-[10px] text-emerald-400 font-medium">Pakistan</span>
                  </div>
                </button>

                {/* Paytm / UPI (India) */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('paytm')}
                  className={`p-2.5 sm:p-3 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    paymentMethod === 'paytm'
                      ? 'bg-sky-950/60 border-sky-500 shadow-md shadow-sky-500/10 ring-1 ring-sky-500/30 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="w-7 h-7 rounded-lg bg-sky-500/20 border border-sky-500/40 flex items-center justify-center shrink-0 mb-2">
                    <CreditCard className="w-4 h-4 text-sky-400" />
                  </div>
                  <div>
                    <span className="block font-bold text-white text-xs">Paytm / UPI</span>
                    <span className="text-[10px] text-sky-400 font-medium">India</span>
                  </div>
                </button>

                {/* PayPal (Global / India) */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('paypal')}
                  className={`p-2.5 sm:p-3 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    paymentMethod === 'paypal'
                      ? 'bg-indigo-950/60 border-indigo-500 shadow-md shadow-indigo-500/10 ring-1 ring-indigo-500/30 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="w-7 h-7 rounded-lg bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center shrink-0 mb-2">
                    <Globe className="w-4 h-4 text-indigo-400" />
                  </div>
                  <div>
                    <span className="block font-bold text-white text-xs">PayPal</span>
                    <span className="text-[10px] text-indigo-400 font-medium">Global</span>
                  </div>
                </button>
              </div>
            </div>

            {/* Official Payment Account Details */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Account Title:</span>
                <span className="text-amber-400 font-bold text-sm">{activeAccount.accountTitle}</span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <div className="overflow-hidden">
                  <span className="text-[11px] text-slate-400 block">{activeAccount.network}</span>
                  <span className="text-base font-mono font-bold text-white break-all tracking-wide">
                    {activeAccount.accountNumber}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy(activeAccount.accountNumber)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs flex items-center gap-1.5 shrink-0 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied!' : 'Copy'}</span>
                </button>
              </div>
              <div className="text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
                {activeAccount.instructionsEn}
              </div>
            </div>

            {/* Sender Inputs */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {paymentMethod === 'easypaisa'
                    ? 'Your Sender EasyPaisa Number *'
                    : paymentMethod === 'paytm'
                    ? 'Your Sender Paytm / UPI ID or Mobile *'
                    : 'Your Sender PayPal Email Address *'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={
                    paymentMethod === 'easypaisa'
                      ? 'e.g. 0312-3456789'
                      : paymentMethod === 'paytm'
                      ? 'e.g. user@paytm or 9876543210'
                      : 'e.g. yourname@gmail.com'
                  }
                  value={senderAccount}
                  onChange={(e) => setSenderAccount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {paymentMethod === 'easypaisa'
                    ? 'Transaction ID (TID from 3737 SMS) *'
                    : paymentMethod === 'paytm'
                    ? 'Paytm / UPI 12-Digit Reference or Order ID *'
                    : 'PayPal Transaction ID / Receipt Number *'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={
                    paymentMethod === 'easypaisa'
                      ? 'e.g. 8492019482 (3737 SMS)'
                      : paymentMethod === 'paytm'
                      ? 'e.g. 428910284719 (UPI Ref)'
                      : 'e.g. 9B38291048K'
                  }
                  value={trxId}
                  onChange={(e) => setTrxId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('proofNote')}
                </label>
                <input
                  type="text"
                  placeholder="Optional memo or transaction note"
                  value={proofNote}
                  onChange={(e) => setProofNote(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs sm:text-sm rounded-lg shadow transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>{t('submitDeposit')} (Rs. {amountPKR.toLocaleString()})</span>
                <ArrowRight className="w-4 h-4 stroke-[2.5]" />
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
