import React from 'react';
import { useApp } from '../context/AppContext';
import {
  TrendingUp,
  ShieldCheck,
  SlidersHorizontal,
  LogOut,
  User,
  Wallet,
  Layers,
  History,
  Activity
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    currency,
    setCurrency,
    currentRoleView,
    setCurrentRoleView,
    activeNavTab,
    setActiveNavTab,
    depositRequests,
    withdrawalRequests,
    currentAccount,
    isAdmin,
    logout,
    t
  } = useApp();

  const pendingDepositsCount = depositRequests.filter((d) => d.status === 'pending').length;
  const pendingWithdrawalsCount = withdrawalRequests.filter((w) => w.status === 'pending').length;
  const totalPendingApprovals = pendingDepositsCount + pendingWithdrawalsCount;

  const navItems: Array<{ id: string; label: string; icon: any; badge?: string }> = [
    { id: 'dashboard', label: 'Dashboard', icon: Wallet },
    { id: 'plans', label: 'Plans', icon: Layers },
    { id: 'ledger', label: 'History', icon: History },
    { id: 'trades', label: 'Trades', icon: Activity }
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800">
      {/* Top Mobile/Desktop WhatsApp-style Bar */}
      <div className="max-w-2xl mx-auto px-4 py-2.5 flex items-center justify-between gap-3">
        {/* Left: Brand name */}
        <div
          onClick={() => {
            setActiveNavTab('dashboard');
            if (currentRoleView === 'manager') setCurrentRoleView('investor');
          }}
          className="flex items-center gap-2 cursor-pointer select-none shrink-0"
        >
          <div className="w-8 h-8 rounded-lg bg-emerald-500 text-slate-950 flex items-center justify-center font-bold">
            <TrendingUp className="w-5 h-5 stroke-[2.5]" />
          </div>
          <div>
            <span className="font-bold text-white text-sm sm:text-base tracking-tight block leading-tight">
              FASTTEST PROFIT
            </span>
            <span className="text-[10px] text-emerald-400 font-semibold block leading-none">
              Daily 24h Payouts
            </span>
          </div>
        </div>

        {/* Right: Currency + User + Admin toggle + Logout */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Admin Switcher (Restricted to Admin Only) */}
          {isAdmin && (
            <button
              onClick={() => setCurrentRoleView(currentRoleView === 'investor' ? 'manager' : 'investor')}
              className={`px-2.5 py-1 rounded text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer ${
                currentRoleView === 'manager'
                  ? 'bg-amber-400 text-slate-950'
                  : 'bg-slate-800 text-amber-400 border border-amber-500/30'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">
                {currentRoleView === 'manager' ? 'Admin' : 'Admin'}
              </span>
              {totalPendingApprovals > 0 && (
                <span className="px-1 py-0.2 rounded-full bg-rose-500 text-white text-[9px] font-bold">
                  {totalPendingApprovals}
                </span>
              )}
            </button>
          )}

          {/* Currency Toggle */}
          <div className="flex items-center bg-slate-800 rounded border border-slate-700 p-0.5 text-[11px] font-mono">
            <button
              onClick={() => setCurrency('PKR')}
              className={`px-1.5 py-0.5 rounded transition-colors ${
                currency === 'PKR' ? 'bg-slate-700 text-emerald-400 font-bold' : 'text-slate-400'
              }`}
            >
              PKR
            </button>
            <button
              onClick={() => setCurrency('USD')}
              className={`px-1.5 py-0.5 rounded transition-colors ${
                currency === 'USD' ? 'bg-slate-700 text-white font-bold' : 'text-slate-400'
              }`}
            >
              USD
            </button>
          </div>



          {/* User & Logout */}
          {currentAccount && (
            <div className="flex items-center gap-1.5 pl-1">
              <div className="hidden sm:flex items-center gap-1 px-2 py-1 rounded bg-slate-800 text-slate-200 text-xs">
                <User className="w-3 h-3 text-slate-400" />
                <span className="max-w-[70px] truncate">{currentAccount.username}</span>
              </div>
              <button
                onClick={() => logout()}
                title="Log Out"
                className="p-1.5 rounded bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-300 border border-slate-700 transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* WhatsApp-style Sub-navigation Tabs (Straight line bar) */}
      <nav className="max-w-2xl mx-auto px-2 flex items-center border-t border-slate-800/80 text-xs font-semibold">
        {navItems.map((item) => {
          const isActive = activeNavTab === item.id && currentRoleView === 'investor';
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              onClick={() => {
                setActiveNavTab(item.id);
                if (currentRoleView === 'manager') setCurrentRoleView('investor');
              }}
              className={`flex-1 py-2.5 text-center flex items-center justify-center gap-1 transition-colors border-b-2 cursor-pointer text-[11px] sm:text-xs ${
                isActive
                  ? 'border-emerald-400 text-emerald-400 font-bold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{item.label}</span>
              {item.badge && (
                <span className="px-1 py-0.2 rounded-full bg-amber-400 text-slate-950 font-black text-[9px]">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}

        {isAdmin && currentRoleView === 'manager' && (
          <button
            onClick={() => setActiveNavTab('manager')}
            className={`flex-1 py-2.5 text-center flex items-center justify-center gap-1.5 transition-colors border-b-2 cursor-pointer ${
              activeNavTab === 'manager'
                ? 'border-amber-400 text-amber-300 font-bold'
                : 'border-transparent text-amber-400/70 hover:text-amber-300'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Admin Console</span>
          </button>
        )}
      </nav>
    </header>
  );
};
