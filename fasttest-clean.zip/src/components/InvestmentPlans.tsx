import React from 'react';
import { useApp } from '../context/AppContext';
import { Check, ArrowRight, Zap, Layers } from 'lucide-react';
import { InvestmentPlan } from '../types';

export const InvestmentPlans: React.FC = () => {
  const {
    plans,
    currentUser,
    formatMoney,
    setSelectedPlanForDeposit,
    setIsDepositModalOpen
  } = useApp();

  const handleSelectPlan = (plan: InvestmentPlan) => {
    setSelectedPlanForDeposit(plan);
    setIsDepositModalOpen(true);
  };

  return (
    <div className="space-y-4 max-w-2xl mx-auto font-sans">
      {/* Straight Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div className="flex items-center gap-2">
          <Layers className="w-5 h-5 text-emerald-400" />
          <h2 className="text-base sm:text-lg font-bold text-white">
            Daily Investment Plans
          </h2>
        </div>
        <p className="text-xs text-slate-400 mt-1">
          Authorized deposit tiers from Rs. 1,000 to Rs. 1,00,000. Profit credited every 24 hours.
        </p>
      </div>

      {/* Straight Vertical Feed: One Plan after Another (WhatsApp List Style) */}
      <div className="space-y-3">
        {plans.map((plan) => {
          const isUserPlan = currentUser?.activePlanId === plan.id;
          const dailyAmountPKR =
            plan.id === 'plan_1k' ? 'Rs. 70' :
            plan.id === 'plan_3k' ? 'Rs. 300' :
            plan.id === 'plan_7k' ? 'Rs. 700' :
            plan.id === 'plan_10k' ? 'Rs. 1,500' :
            'Rs. 3,000+';

          return (
            <div
              key={plan.id}
              className={`rounded-xl bg-slate-900 border p-4 transition-colors ${
                plan.isPopular
                  ? 'border-emerald-500/60 bg-slate-900 ring-1 ring-emerald-500/30'
                  : 'border-slate-800'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-white text-sm sm:text-base">
                      {plan.nameEn}
                    </h3>
                    {plan.isPopular && (
                      <span className="bg-emerald-500 text-slate-950 text-[10px] font-bold px-2 py-0.5 rounded">
                        POPULAR
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    {plan.descriptionEn}
                  </p>
                </div>

                {/* Return Rate Callout */}
                <div className="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-right shrink-0">
                  <span className="text-[10px] text-slate-400 block leading-none">Daily Profit</span>
                  <span className="text-lg font-bold font-mono text-emerald-400 tabular-nums">
                    +{plan.dailyRoiMin}%
                  </span>
                  <span className="text-[10px] font-bold text-amber-300 block font-mono">
                    {dailyAmountPKR}/day
                  </span>
                </div>
              </div>

              {/* Details Row: Straight Line */}
              <div className="grid grid-cols-3 gap-2 py-3 my-2 border-y border-slate-800/80 text-xs">
                <div>
                  <span className="text-[10px] text-slate-500 block">Min Deposit</span>
                  <span className="font-mono font-bold text-white">
                    {formatMoney(plan.minDepositPKR)}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">Max Deposit</span>
                  <span className="font-mono font-bold text-white">
                    {formatMoney(plan.maxDepositPKR)}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">Payout Cycle</span>
                  <span className="font-semibold text-emerald-400">
                    24 Hours
                  </span>
                </div>
              </div>

              {/* Action Button */}
              <div>
                {isUserPlan ? (
                  <button
                    disabled
                    className="w-full py-2 bg-emerald-950/80 border border-emerald-600/40 text-emerald-400 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Your Active Investment Tier</span>
                  </button>
                ) : (
                  <button
                    onClick={() => handleSelectPlan(plan)}
                    className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <span>Deposit into this Plan</span>
                    <ArrowRight className="w-3.5 h-3.5 stroke-[2.5]" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
