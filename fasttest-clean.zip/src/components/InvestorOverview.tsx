import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  Wallet,
  TrendingUp,
  ArrowDownLeft,
  ArrowUpRight,
  ShieldCheck,
  Clock,
  CheckCircle2,
  Hourglass,
  Zap,
  Smartphone,
  CreditCard,
  Globe,
  ChevronRight,
  MessageCircle,
  Sparkles,
  XCircle
} from 'lucide-react';
import { ALLOWED_DEPOSIT_AMOUNTS } from './DepositModal';
import { getDailyRoiRate, getExpectedDailyProfit } from '../data/mockData';

export const InvestorOverview: React.FC = () => {
  const {
    currentUser,
    plans,
    dailyProfits,
    depositRequests,
    withdrawalRequests,
    transactions,
    formatMoney,
    setIsDepositModalOpen,
    setIsWithdrawModalOpen,
    setSelectedPlanForDeposit,
    setActiveNavTab,
    language,
    t
  } = useApp();

  const safeCurrentUser = currentUser || {
    id: '',
    name: '',
    capitalInvestedPKR: 0,
    availableBalancePKR: 0,
    totalProfitEarnedPKR: 0,
    activePlanId: '',
    status: 'active' as const,
    nextProfitTimestamp: 0
  };

  const hasActiveDeposit = (safeCurrentUser.capitalInvestedPKR || 0) > 0;
  const currentRoiRate = getDailyRoiRate(safeCurrentUser.capitalInvestedPKR || 0);
  const expectedDailyProfit = getExpectedDailyProfit(safeCurrentUser.capitalInvestedPKR || 0);

  // Target timestamp for next 24h payout (from server or default 24h)
  const targetProfitTime =
    safeCurrentUser.nextProfitTimestamp ||
    (hasActiveDeposit ? Date.now() + 24 * 60 * 60 * 1000 : 0);

  const [remainingSeconds, setRemainingSeconds] = useState<number>(() => {
    if (!hasActiveDeposit || !targetProfitTime) return 0;
    return Math.max(0, Math.floor((targetProfitTime - Date.now()) / 1000));
  });

  useEffect(() => {
    if (!hasActiveDeposit || !targetProfitTime) {
      setRemainingSeconds(0);
      return;
    }

    // Immediately calculate initial
    const initialSec = Math.max(0, Math.floor((targetProfitTime - Date.now()) / 1000));
    setRemainingSeconds(initialSec);

    const interval = setInterval(() => {
      const diffSec = Math.max(0, Math.floor((targetProfitTime - Date.now()) / 1000));
      setRemainingSeconds(diffSec);

      // When timer hits 0, trigger automated backend distribution check
      if (diffSec <= 0) {
        fetch('https://ais-pre-qmdo4ttshkqc2cntv3rbos-883594426031.asia-east1.run.app/api/check-profits', { method: 'POST' }).catch(() => {});
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [hasActiveDeposit, targetProfitTime]);

  const hours = Math.floor(remainingSeconds / 3600);
  const minutes = Math.floor((remainingSeconds % 3600) / 60);
  const seconds = remainingSeconds % 60;

  const activePlan = plans.find((p) => p.id === safeCurrentUser.activePlanId) || plans[0];
  const userPendingDeposits = depositRequests.filter(
    (d) => d.investorId === safeCurrentUser.id && d.status === 'pending'
  );
  const userPendingWithdrawals = withdrawalRequests.filter(
    (w) => w.investorId === safeCurrentUser.id && w.status === 'pending'
  );
  const userProfits = dailyProfits.filter((dp) => dp.investorId === safeCurrentUser.id);

  // User's transactions only, straight matching
  const userTransactions = transactions.filter(
    (tx) =>
      tx.investorId === safeCurrentUser.id ||
      (safeCurrentUser.name && tx.descriptionEn.toLowerCase().includes(safeCurrentUser.name.toLowerCase()))
  );

  const handleQuickDepositAmount = (amt: number) => {
    const matchingPlan = plans.find((p) => p.minDepositPKR === amt) || plans.find((p) => amt >= p.minDepositPKR) || plans[0];
    if (matchingPlan) {
      setSelectedPlanForDeposit(matchingPlan);
    }
    setIsDepositModalOpen(true);
  };

  return (
    <div className="space-y-4 font-sans max-w-2xl mx-auto">
      {/* BLOCKED ACCOUNT SUSPENSION NOTICE */}
      {(safeCurrentUser.status === 'paused' || safeCurrentUser.status === 'blocked') && (
        <div className="bg-rose-950 border border-rose-500 rounded-xl p-4 space-y-2 text-xs text-rose-200 shadow-xl">
          <div className="flex items-center gap-2 text-rose-300 font-bold text-sm">
            <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
            <span>Account Suspended / Blocked by Admin</span>
          </div>
          <p className="text-slate-300 text-xs leading-relaxed">
            Your account has been suspended by Fund Administration for policy review or rule violation. Deposit and withdrawal capabilities are temporarily locked.
          </p>
          <a
            href="https://t.me/FASTTEST_ADMIN"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs rounded-lg transition-colors cursor-pointer"
          >
            <span>Contact @FASTTEST_ADMIN on Telegram</span>
          </a>
        </div>
      )}


      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 sm:p-5">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span className="flex items-center gap-1.5 font-medium">
            <Wallet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Available Balance (Withdrawable)</span>
          </span>
          <span className="text-[11px] text-emerald-400 font-semibold bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800/40">
            {hasActiveDeposit ? '24h Cycle Active' : 'Account Ready'}
          </span>
        </div>

        {/* Large Straight Balance Display */}
        <div className="text-3xl sm:text-4xl font-extrabold font-mono tabular-nums text-white my-2">
          {formatMoney(safeCurrentUser.availableBalancePKR || 0)}
        </div>

        {/* Linear sub-metrics */}
        <div className="grid grid-cols-2 gap-2 pt-3 border-t border-slate-800 text-xs">
          {hasActiveDeposit && (
            <>
              <div>
                <span className="text-slate-400 block text-[11px]">Active Invested Capital</span>
                <span className="font-mono font-bold text-white text-sm">
                  {formatMoney(safeCurrentUser.capitalInvestedPKR || 0)}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Total Profit Earned</span>
                <span className="font-mono font-bold text-emerald-400 text-sm">
                  +{formatMoney(safeCurrentUser.totalProfitEarnedPKR || 0)}
                </span>
              </div>
            </>
          )}
        </div>

        {/* Direct Action Buttons: Straight side-by-side */}
        <div className="grid grid-cols-2 gap-2.5 mt-4 pt-1">
          <button
            onClick={() => setIsDepositModalOpen(true)}
            className="py-2.5 px-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs sm:text-sm rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <ArrowDownLeft className="w-4 h-4 stroke-[2.5]" />
            <span>+ Deposit Money</span>
          </button>
          <button
            onClick={() => setIsWithdrawModalOpen(true)}
            className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-semibold text-xs sm:text-sm rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <ArrowUpRight className="w-4 h-4 text-emerald-400" />
            <span>↗ Cashout</span>
          </button>
        </div>
      </div>

      {/* LINE 2: REAL 24-HOUR PROFIT TIMER (No Fake Time!) */}
      {hasActiveDeposit ? (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 sm:p-3.5 space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400 fill-amber-400" />
              <div>
                <span className="text-white font-bold block leading-tight">
                  Next 24-Hour Profit Countdown
                </span>
                <span className="text-[10px] text-slate-400 block">
                  Automated payout · Updates in real time
                </span>
              </div>
            </div>

            <div className="font-mono font-extrabold text-amber-300 tracking-wider text-sm sm:text-base bg-slate-950 px-3 py-1.5 rounded-lg border border-amber-500/30">
              {String(hours).padStart(2, '0')}h : {String(minutes).padStart(2, '0')}m : {String(seconds).padStart(2, '0')}s
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-300 pt-2 border-t border-slate-800/80">
            <span>Next Automatic Payout:</span>
            <span className="font-mono font-bold text-emerald-400">
              +{formatMoney(expectedDailyProfit)} ({currentRoiRate}% Daily)
            </span>
          </div>

          <div className="text-[10px] text-emerald-400/90 flex items-center gap-1 bg-emerald-950/40 p-2 rounded-lg border border-emerald-800/40">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>
              First Day Profit was credited instantly upon approval & is ready for withdrawal.
            </span>
          </div>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 text-xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-slate-800 text-amber-400 flex items-center justify-center font-bold">
                <Clock className="w-4 h-4 text-amber-400" />
              </div>
              <div>
                <span className="text-white font-bold block">
                  24h Timer: 00h : 00m : 00s (Cycle Inactive)
                </span>
                <span className="text-[10px] text-slate-400 block">
                  Deposit required to activate 24-hour payout engine
                </span>
              </div>
            </div>

            <button
              onClick={() => setIsDepositModalOpen(true)}
              className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-lg transition-colors cursor-pointer shrink-0"
            >
              + Deposit Now
            </button>
          </div>

          <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-[11px] text-emerald-200/90 leading-relaxed">
            💡 <strong>پرافٹ کی تفصیل:</strong> جب آپ ڈپازٹ کر لو گے، اس ٹائم پہ آپ کو فرسٹ پرافٹ اسی ٹائم ملے گا اور نیکسٹ پرافٹ آپ کو ہر 24 گھنٹے بعد روزانہ ملے گا اور یہ آپ کو ٹوٹل 60 دن تک پرافٹ ملے گا۔
          </div>
        </div>
      )}

      {/* LINE 3: Pending Approval Alert (if any active requests) */}
      {(userPendingDeposits.length > 0 || userPendingWithdrawals.length > 0) && (
        <div className="bg-amber-950/40 border border-amber-500/40 rounded-xl p-3 text-xs space-y-1.5">
          <div className="flex items-center gap-2 font-bold text-amber-300">
            <Hourglass className="w-4 h-4 animate-spin text-amber-400" />
            <span>Requests Awaiting Admin Approval</span>
          </div>
          {userPendingDeposits.map((d) => (
            <p key={d.id} className="text-slate-300 text-[11px]">
              • Deposit of <strong className="text-white">Rs. {d.amountPKR.toLocaleString()}</strong> ({d.paymentMethod.toUpperCase()} TID: {d.transactionId}) is pending. As soon as Admin approves, your <strong>First Day Profit</strong> will credit immediately and the 24h countdown begins!
            </p>
          ))}
          {userPendingWithdrawals.map((w) => (
            <p key={w.id} className="text-slate-300 text-[11px]">
              • Withdrawal of <strong className="text-white">Rs. {w.amountPKR.toLocaleString()}</strong> ({w.paymentMethod.toUpperCase()}) is in queue for payout.
            </p>
          ))}
        </div>
      )}

      {/* LINE 4: Quick 1-Click Deposit Amounts (The 8 Authorized Amounts) */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div className="flex items-center justify-between text-xs mb-2.5">
          <span className="font-bold text-white">Quick Deposit Amounts</span>
          <span className="text-[11px] text-slate-400">EasyPaisa · Paytm · PayPal</span>
        </div>

        <div className="grid grid-cols-4 gap-2">
          {ALLOWED_DEPOSIT_AMOUNTS.map((amt) => (
            <button
              key={amt}
              onClick={() => handleQuickDepositAmount(amt)}
              className="py-2 px-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-emerald-500 rounded-lg text-center transition-colors cursor-pointer"
            >
              <span className="block font-mono text-xs font-bold text-white">
                {amt >= 100000 ? '1 Lakh' : `${amt / 1000}k`}
              </span>
              <span className="text-[9px] text-slate-500 block leading-tight">
                Rs. {amt.toLocaleString()}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* LINE 5: Recent Transactions (WhatsApp Chat-List Style Feed) */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        <div className="p-3.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-400" />
            <h3 className="font-bold text-white text-xs sm:text-sm">
              Transaction History
            </h3>
          </div>
          <button
            onClick={() => setActiveNavTab('ledger')}
            className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-0.5 cursor-pointer"
          >
            <span>See All</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Straight Vertical Rows (Like WhatsApp Messages) */}
        <div className="divide-y divide-slate-800/80">
          {userTransactions.slice(0, 6).length === 0 ? (
            <div className="py-8 text-center text-slate-500 text-xs">
              No transactions yet. Click "+ Deposit Money" to get started.
            </div>
          ) : (
            userTransactions.slice(0, 6).map((tx) => {
              const descLower = (tx.descriptionEn || '').toLowerCase();
              const isEasyPaisa = tx.paymentMethod === 'easypaisa' || descLower.includes('easypaisa');
              const isJazzCash = tx.paymentMethod === 'jazzcash' || descLower.includes('jazzcash');
              const isPaytm = tx.paymentMethod === 'paytm' || descLower.includes('paytm') || descLower.includes('upi');
              const isPaypal = tx.paymentMethod === 'paypal' || descLower.includes('paypal');

              return (
                <div
                  key={tx.id}
                  className="p-3 flex items-center justify-between gap-3 hover:bg-slate-800/40 transition-colors"
                >
                  {/* Left: Round Gateway Icon (Like WhatsApp Avatar) */}
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 border ${
                        tx.type === 'PROFIT'
                          ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-400'
                          : isEasyPaisa
                          ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-400'
                          : isJazzCash
                          ? 'bg-amber-950/80 border-amber-500/40 text-amber-400'
                          : isPaytm
                          ? 'bg-sky-950/80 border-sky-500/40 text-sky-400'
                          : isPaypal
                          ? 'bg-indigo-950/80 border-indigo-500/40 text-indigo-400'
                          : 'bg-slate-800 border-slate-700 text-slate-300'
                      }`}
                    >
                      {tx.type === 'PROFIT' ? (
                        <TrendingUp className="w-4 h-4" />
                      ) : isEasyPaisa || isJazzCash ? (
                        <Smartphone className="w-4 h-4" />
                      ) : isPaytm ? (
                        <CreditCard className="w-4 h-4" />
                      ) : isPaypal ? (
                        <Globe className="w-4 h-4" />
                      ) : (
                        <Wallet className="w-4 h-4" />
                      )}
                    </div>

                    {/* Middle: Title & Date (Like WhatsApp Chat Name & Last Message) */}
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-white truncate">
                        {tx.type === 'PROFIT'
                          ? 'Daily 24h Profit Credited'
                          : tx.type === 'DEPOSIT'
                          ? `Deposit (${isEasyPaisa ? 'EasyPaisa' : isJazzCash ? 'JazzCash' : isPaytm ? 'Paytm' : isPaypal ? 'PayPal' : 'Wallet'})`
                          : `Withdrawal (${isEasyPaisa ? 'EasyPaisa' : isJazzCash ? 'JazzCash' : isPaytm ? 'Paytm' : isPaypal ? 'PayPal' : 'Payout'})`}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono truncate mt-0.5">
                        {tx.date} {tx.referenceId && `· TID: ${tx.referenceId}`}
                      </div>
                    </div>
                  </div>

                  {/* Right: Amount & Status Badge */}
                  <div className="text-right shrink-0">
                    <div
                      className={`text-xs sm:text-sm font-bold font-mono ${
                        tx.type === 'WITHDRAWAL' ? 'text-rose-400' : 'text-emerald-400'
                      }`}
                    >
                      {tx.type === 'WITHDRAWAL' ? '-' : '+'}
                      {formatMoney(tx.amountPKR)}
                    </div>
                    <div className="mt-0.5">
                      {tx.status === 'PENDING' ? (
                        <span className="inline-flex items-center gap-1 text-[9px] font-bold text-amber-300 bg-amber-950/80 px-1.5 py-0.2 rounded border border-amber-500/40">
                          <span className="w-1 h-1 rounded-full bg-amber-400 animate-pulse" />
                          Pending
                        </span>
                      ) : tx.status === 'COMPLETED' ? (
                        <span className="inline-flex items-center gap-0.5 text-[9px] font-bold text-emerald-400 bg-emerald-950/80 px-1.5 py-0.2 rounded border border-emerald-800/50">
                          <CheckCircle2 className="w-2.5 h-2.5" />
                          Approved
                        </span>
                      ) : (
                        <span className="text-[9px] font-bold text-rose-400 bg-rose-950/80 px-1.5 py-0.2 rounded">
                          Declined
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* LINE 6: Investment Plans Shortcut (Straight Line Card) */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
        <div>
          <span className="text-[11px] text-amber-400 font-bold block">
            Investment Plans
          </span>
          <span className="text-xs font-semibold text-white block mt-0.5">
            Earn 15% to 35% Daily Profit (Rs. 3,000 – 1 Lakh)
          </span>
        </div>
        <button
          onClick={() => setActiveNavTab('plans')}
          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-lg border border-slate-700 cursor-pointer"
        >
          View Plans
        </button>
      </div>

      {/* LINE 7: Direct Telegram Support Bar */}
      <a
        href="https://t.me/FASTTEST_ADMIN"
        target="_blank"
        rel="noopener noreferrer"
        className="w-full bg-[#1e293b] hover:bg-[#334155] border border-slate-700/80 rounded-xl p-3 flex items-center justify-between text-xs transition-colors cursor-pointer"
      >
        <div className="flex items-center gap-2.5 text-white">
          <div className="w-8 h-8 rounded-full bg-[#229ED9] text-white flex items-center justify-center font-bold">
            <MessageCircle className="w-4 h-4 fill-white" />
          </div>
          <div>
            <span className="font-bold text-white block">Official Telegram Support</span>
            <span className="text-[10px] text-slate-400 block">Contact @FASTTEST_ADMIN 24/7</span>
          </div>
        </div>
        <span className="text-[11px] font-semibold text-[#229ED9]">Chat Now →</span>
      </a>
    </div>
  );
};
