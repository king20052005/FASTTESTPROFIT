import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { useApp } from '../context/AppContext';
import {
  Download,
  Smartphone,
  Share2,
  Check,
  X,
  Sparkles,
  ExternalLink,
  Code
} from 'lucide-react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const { language } = useApp();
  const [showModal, setShowModal] = useState(false);

  // If already installed and running standalone, hide button
  if (isInstalled) {
    return null;
  }

  const handleButtonClick = () => {
    if (isInstallable) {
      install();
    } else {
      setShowModal(true);
    }
  };

  return (
    <>
      <button
        onClick={handleButtonClick}
        className="px-2.5 py-1 rounded bg-gradient-to-r from-amber-500/20 to-amber-400/20 hover:from-amber-500/30 hover:to-amber-400/30 text-amber-300 border border-amber-500/40 text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm"
      >
        <Download className="w-3.5 h-3.5" />
        <span>{language === 'ur' ? 'موبائل ایپ انسٹال کریں' : 'Install Mobile App'}</span>
      </button>

      {/* Guide Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-7 my-8 space-y-6">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Header */}
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-amber-400/10 border border-amber-400/30 flex items-center justify-center text-amber-400 shrink-0">
                <Smartphone className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">
                  {language === 'ur' ? 'موبائل پر ایپ کیسے انسٹال کریں؟' : 'How to Install on Mobile (PWA & APK)'}
                </h3>
                <p className="text-xs text-slate-400">
                  {language === 'ur'
                    ? 'یہ ایپ بغیر پلے اسٹور کے بھی سیدھی آپ کے موبائل پر انسٹال ہو سکتی ہے!'
                    : 'This app is a fully compliant PWA that runs full screen just like a native app.'}
                </p>
              </div>
            </div>

            {/* Method 1: Instant PWA Install on Android / iPhone */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                <Check className="w-4 h-4" />
                <span>{language === 'ur' ? 'طریقہ 1: فوری موبائل پر انسٹال کریں (سب سے آسان)' : 'Method 1: Instant Direct Install (Recommended)'}</span>
              </div>

              <div className="space-y-2 text-xs text-slate-300">
                <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                  <strong className="text-white block mb-0.5">Android (Chrome):</strong>
                  <span>
                    {language === 'ur'
                      ? 'کروم براؤزر کے اوپر 3 ڈاٹس (⋮) پر کلک کریں اور "Install app" یا "Add to Home screen" منتخب کریں۔ ایپ کا آئیکون فون پر آ جائے گا۔'
                      : 'Open in Chrome on Android. Tap the 3 dots menu (⋮) -> tap "Install app" or "Add to Home screen".'}
                  </span>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                  <strong className="text-white block mb-0.5">iPhone / iPad (Safari):</strong>
                  <span>
                    {language === 'ur'
                      ? 'سفاری میں نیچے شیئر بٹن پر کلک کریں، پھر نیچے اسکرول کر کے "Add to Home Screen" پر ٹیپ کریں۔'
                      : 'Open in Safari. Tap the Share button at bottom -> tap "Add to Home Screen".'}
                  </span>
                </div>
              </div>
            </div>

            {/* Method 2: Android APK File */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
                <Code className="w-4 h-4" />
                <span>{language === 'ur' ? 'طریقہ 2: اینڈرائیڈ APK فائل بنانا (Google Play / Telegram)' : 'Method 2: Convert to Standalone Android APK (.apk)'}</span>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">
                {language === 'ur'
                  ? 'اگر آپ کلائنٹس کو باقاعدہ .apk فائل یا Play Store پر دینا چاہتے ہیں، تو آپ PWABuilder (pwabuilder.com) پر اپنی سائٹ کا لنک ڈال کر 2 منٹ میں فری اینڈرائیڈ APK بنا سکتے ہیں، یا Capacitor استعمال کر سکتے ہیں۔'
                  : 'To distribute an actual .apk file to clients or publish to Google Play Store, simply paste your app URL into PWABuilder (pwabuilder.com) to generate a signed Android APK package.'}
              </p>

              <div className="text-[11px] font-mono text-slate-400 bg-slate-900 p-2 rounded border border-slate-800 flex items-center justify-between">
                <span>Tool: PWABuilder.com / Capacitor CLI</span>
                <span className="text-emerald-400 font-bold">100% PWA Ready</span>
              </div>
            </div>

            <button
              onClick={() => setShowModal(false)}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-colors"
            >
              {language === 'ur' ? 'سمجھ آ گئی (بند کریں)' : 'Got it (Close)'}
            </button>
          </div>
        </div>
      )}
    </>
  );
};
