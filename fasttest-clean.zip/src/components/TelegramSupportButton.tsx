import React, { useState } from 'react';
import { Copy, Check, ExternalLink } from 'lucide-react';

export const TelegramSupportButton: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const telegramUsername = 'FASTTEST_ADMIN';
  const telegramHandle = `@${telegramUsername}`;
  const telegramUrl = `https://t.me/${telegramUsername}`;

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    navigator.clipboard.writeText(telegramHandle);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className="fixed bottom-3 right-3 z-50 flex items-center gap-1.5 bg-slate-900/95 backdrop-blur-md border border-sky-500/40 hover:border-sky-400 text-white rounded-full py-1 px-2.5 shadow-lg shadow-black/50 select-none"
      role="region"
      aria-label="Telegram Support"
    >
      {/* Clickable link directly to Telegram handle */}
      <a
        href={telegramUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-1.5 group cursor-pointer"
        title="Contact Admin on Telegram (@FASTTEST_ADMIN)"
      >
        <div className="w-5 h-5 rounded-full bg-[#229ED9] flex items-center justify-center text-white shrink-0 shadow-sm">
          <svg className="w-3 h-3 fill-current transform -translate-x-0.5 translate-y-0.5" viewBox="0 0 24 24">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.75-.55 2.92-1.27 4.86-2.11 5.83-2.52 2.77-1.18 3.35-1.38 3.73-1.39.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z" />
          </svg>
        </div>

        <span className="text-[11px] font-mono font-bold text-sky-400 group-hover:text-sky-300">
          {telegramHandle}
        </span>
        <ExternalLink className="w-2.5 h-2.5 text-slate-400 group-hover:text-sky-300" />
      </a>

      {/* Copy ID Button */}
      <button
        type="button"
        onClick={handleCopy}
        className="p-0.5 rounded hover:bg-slate-800 text-slate-400 hover:text-emerald-400 transition-colors ml-0.5 cursor-pointer"
        title="Copy Telegram ID"
        aria-label="Copy Telegram Handle"
      >
        {copied ? (
          <Check className="w-3 h-3 text-emerald-400" />
        ) : (
          <Copy className="w-3 h-3" />
        )}
      </button>
    </div>
  );
};
