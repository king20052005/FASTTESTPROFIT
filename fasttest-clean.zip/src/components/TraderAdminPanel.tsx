import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  SlidersHorizontal,
  Users,
  ArrowDownLeft,
  ArrowUpRight,
  PlusCircle,
  Check,
  X,
  TrendingUp,
  RotateCcw,
  ShieldCheck,
  Copy,
  Clock,
  CheckCircle2,
  XCircle,
  Smartphone,
  CreditCard,
  Globe
} from 'lucide-react';
import { TradeLog } from '../types';
import { getDailyRoiRate, getExpectedDailyProfit } from '../data/mockData';

export const TraderAdminPanel: React.FC = () => {
  const {
    allInvestors = [],
    setCurrentUser,
    currentUser,
    depositRequests = [],
    withdrawalRequests = [],
    approveDeposit,
    rejectDeposit,
    approveWithdrawal,
    rejectWithdrawal,
    blockInvestor,
    unblockInvestor,
    addTradeLog,
    setIsDistributeModalOpen,
    resetToDemoData,
    formatMoney,
    language,
    t
  } = useApp();

  const [activeTab, setActiveTab] = useState<'deposits' | 'withdrawals' | 'investors' | 'postTrade'>('deposits');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // New trade state
  const [newPair, setNewPair] = useState('XAU/USD (Gold)');
  const [newAction, setNewAction] = useState<'BUY' | 'SELL'>('BUY');
  const [newEntry, setNewEntry] = useState<number>(2745.50);
  const [newExit, setNewExit] = useState<number>(2763.80);
  const [newProfitPercent, setNewProfitPercent] = useState<number>(2.25);
  const [newNotes, setNewNotes] = useState('London session liquidity expansion targeting weekly high.');
  const [tradePosted, setTradePosted] = useState(false);

  const pendingDeposits = depositRequests.filter((d) => d.status === 'pending');
  const pendingWithdrawals = withdrawalRequests.filter((w) => w.status === 'pending');
  const totalAUM = allInvestors.reduce((acc, curr) => acc + curr.capitalInvestedPKR, 0);
  const totalProfitsPaid = allInvestors.reduce((acc, curr) => acc + curr.totalProfitEarnedPKR, 0);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const handlePostTrade = (e: React.FormEvent) => {
    e.preventDefault();
    const trade: Omit<TradeLog, 'id'> = {
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      assetPair: newPair,
      action: newAction,
      entryPrice: newEntry,
      exitPrice: newExit,
      profitPercentage: newProfitPercent,
      pnlPKR: Math.round(newProfitPercent * 350000),
      notes: newNotes,
      status: 'CLOSED'
    };

    addTradeLog(trade);
    setTradePosted(true);
    setTimeout(() => setTradePosted(false), 2500);
  };

  return (
    <div className="space-y-4 font-sans">
      {/* LINE 1: Straight Admin Header Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 sm:p-4 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-full bg-amber-400/20 text-amber-400 flex items-center justify-center font-bold">
            <SlidersHorizontal className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm sm:text-base font-bold text-white leading-tight">
              Admin & Approval Console
            </h2>
            <p className="text-[11px] text-slate-400">
              Only visible to Admin ({currentUser?.email || 'zeeshantrader295@gmail.com'})
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsDistributeModalOpen(true)}
            className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-1.5 cursor-pointer"
          >
            <TrendingUp className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>Pay Daily Profit</span>
          </button>
          <button
            onClick={resetToDemoData}
            title="Reset to default sample data"
            className="p-1.5 bg-slate-800 text-slate-400 hover:text-white rounded-lg border border-slate-700 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* LINE 2: Straight Summary Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 grid grid-cols-3 gap-2 text-center">
        <div className="border-r border-slate-800/80 pr-1">
          <span className="text-[10px] text-slate-400 block">Total Capital</span>
          <span className="text-xs sm:text-sm font-bold font-mono text-blue-400">
            {formatMoney(totalAUM)}
          </span>
        </div>
        <div className="border-r border-slate-800/80 pr-1">
          <span className="text-[10px] text-slate-400 block">Total Profits Paid</span>
          <span className="text-xs sm:text-sm font-bold font-mono text-emerald-400">
            +{formatMoney(totalProfitsPaid)}
          </span>
        </div>
        <div>
          <span className="text-[10px] text-slate-400 block">Pending Requests</span>
          <span className="text-xs sm:text-sm font-bold font-mono text-amber-400">
            {pendingDeposits.length + pendingWithdrawals.length}
          </span>
        </div>
      </div>

      {/* LINE 3: Straight Tabs Navigation */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-1 grid grid-cols-4 gap-1 text-[11px] font-bold">
        <button
          onClick={() => setActiveTab('deposits')}
          className={`py-2 rounded-lg text-center transition-all cursor-pointer flex items-center justify-center gap-1 ${
            activeTab === 'deposits'
              ? 'bg-amber-400 text-slate-950 font-black'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <span>Deposits</span>
          {pendingDeposits.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-slate-950 text-amber-300 text-[9px] font-mono">
              {pendingDeposits.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('withdrawals')}
          className={`py-2 rounded-lg text-center transition-all cursor-pointer flex items-center justify-center gap-1 ${
            activeTab === 'withdrawals'
              ? 'bg-amber-400 text-slate-950 font-black'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <span>Cashouts</span>
          {pendingWithdrawals.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-rose-500 text-white text-[9px] font-mono">
              {pendingWithdrawals.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('investors')}
          className={`py-2 rounded-lg text-center transition-all cursor-pointer ${
            activeTab === 'investors'
              ? 'bg-amber-400 text-slate-950 font-black'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <span>Investors ({allInvestors.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('postTrade')}
          className={`py-2 rounded-lg text-center transition-all cursor-pointer ${
            activeTab === 'postTrade'
              ? 'bg-amber-400 text-slate-950 font-black'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <span>+ Trade</span>
        </button>
      </div>

      {/* TAB 1: DEPOSITS APPROVAL FEED (WhatsApp-Style Vertical Slips) */}
      {activeTab === 'deposits' && (
        <div className="space-y-3">
          <div className="bg-amber-950/40 border border-amber-500/30 rounded-xl p-2.5 flex items-start gap-2 text-xs text-amber-200">
            <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <p className="leading-snug">
              When an investor deposits via EasyPaisa, Paytm, or PayPal, their slip appears below. Verify their TID and tap <strong>"Approve & Credit"</strong>. Their deposit will activate, their <strong>First Day Profit</strong> will credit immediately to their withdrawable balance, and their real 24-hour cycle begins.
            </p>
          </div>

          <div className="space-y-2.5">
            {Array.isArray(depositRequests) && depositRequests.length === 0 ? (
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-500 text-xs">
                No deposit slips recorded yet.
              </div>
            ) : (
              (Array.isArray(depositRequests) ? depositRequests : []).map((dep) => {
                const isPending = dep.status === 'pending';
                const isApproved = dep.status === 'approved';

                const roi = getDailyRoiRate(dep.amountPKR);
                const firstProfit = getExpectedDailyProfit(dep.amountPKR);

                return (
                  <div
                    key={dep.id}
                    className={`bg-slate-900 border rounded-xl p-3.5 space-y-2.5 transition-colors ${
                      isPending
                        ? 'border-amber-500/50 bg-slate-900/90'
                        : isApproved
                        ? 'border-emerald-500/30'
                        : 'border-slate-800'
                    }`}
                  >
                    {/* Top Row: Investor & Amount */}
                    <div className="flex items-center justify-between gap-2 border-b border-slate-800/80 pb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center font-bold text-xs text-amber-400">
                          {dep.investorName.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <div className="font-bold text-white text-xs sm:text-sm">
                            {dep.investorName}
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {dep.timestamp}
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-sm sm:text-base font-bold font-mono text-emerald-400 tabular-nums block">
                          +{formatMoney(dep.amountPKR)}
                        </span>
                        <span className="text-[10px] uppercase font-bold text-amber-300">
                          {dep.paymentMethod.replace('_', ' ')}
                        </span>
                      </div>
                    </div>

                    {/* Middle Row: TID & Sender Details & 1st Profit Preview */}
                    <div className="bg-slate-950 border border-slate-800/80 rounded-lg p-2.5 text-xs space-y-1 font-mono">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 text-[11px]">Transaction ID (TID):</span>
                        <button
                          onClick={() => handleCopy(dep.id, dep.transactionId)}
                          className="flex items-center gap-1 text-amber-400 hover:text-white font-bold cursor-pointer"
                        >
                          <span>{dep.transactionId}</span>
                          <Copy className="w-3 h-3" />
                          {copiedId === dep.id && <span className="text-emerald-400 text-[9px]">Copied</span>}
                        </button>
                      </div>

                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-400">Sender Number:</span>
                        <span className="text-slate-200">{dep.senderAccountNumber}</span>
                      </div>

                      <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-900 text-emerald-400">
                        <span>Instant Day 1 Profit:</span>
                        <span className="font-bold">+{formatMoney(firstProfit)} ({roi}% Daily)</span>
                      </div>

                      {dep.adminNote && (
                        <div className="text-slate-400 text-[10px] pt-1 border-t border-slate-900">
                          Note: "{dep.adminNote}"
                        </div>
                      )}
                    </div>

                    {/* Bottom Row: Actions or Status */}
                    <div className="flex items-center justify-between pt-1">
                      <div>
                        {isPending ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-400">
                            <Clock className="w-3.5 h-3.5 animate-spin" />
                            <span>Awaiting Your Approval</span>
                          </span>
                        ) : isApproved ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Approved & Credited</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-400">
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Declined</span>
                          </span>
                        )}
                      </div>

                      {isPending && (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => approveDeposit(dep.id)}
                            className="px-3.5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-1 cursor-pointer"
                          >
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                            <span>Approve & Credit</span>
                          </button>
                          <button
                            onClick={() => rejectDeposit(dep.id)}
                            className="px-2.5 py-1.5 bg-rose-950 text-rose-300 border border-rose-800 hover:bg-rose-900 font-semibold text-xs rounded-lg flex items-center gap-1 cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                            <span>Reject</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* TAB 2: WITHDRAWALS APPROVAL FEED (WhatsApp-Style Vertical Slips) */}
      {activeTab === 'withdrawals' && (
        <div className="space-y-3">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex justify-between items-center text-xs">
            <span className="text-white font-bold">
              Withdrawal Requests ({withdrawalRequests.length})
            </span>
            <span className="text-amber-400 font-medium">
              {pendingWithdrawals.length} Pending payout
            </span>
          </div>

          <div className="space-y-2.5">
            {Array.isArray(withdrawalRequests) && withdrawalRequests.length === 0 ? (
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-500 text-xs">
                No withdrawal requests at this moment.
              </div>
            ) : (
              (Array.isArray(withdrawalRequests) ? withdrawalRequests : []).map((wth) => {
                const isPending = wth.status === 'pending';
                const isApproved = wth.status === 'approved';

                return (
                  <div
                    key={wth.id}
                    className={`bg-slate-900 border rounded-xl p-3.5 space-y-2.5 transition-colors ${
                      isPending
                        ? 'border-rose-500/50 bg-slate-900/90'
                        : isApproved
                        ? 'border-emerald-500/30'
                        : 'border-slate-800'
                    }`}
                  >
                    {/* Header */}
                    <div className="flex items-center justify-between gap-2 border-b border-slate-800/80 pb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center font-bold text-xs text-rose-400">
                          {wth.investorName.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <div className="font-bold text-white text-xs sm:text-sm">
                            {wth.investorName}
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {wth.requestedAt}
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-sm sm:text-base font-bold font-mono text-rose-400 tabular-nums block">
                          -{formatMoney(wth.amountPKR)}
                        </span>
                        <span className="text-[10px] uppercase font-bold text-amber-300">
                          {wth.paymentMethod.replace('_', ' ')}
                        </span>
                      </div>
                    </div>

                    {/* Account Details */}
                    <div className="bg-slate-950 border border-slate-800/80 rounded-lg p-2.5 text-xs space-y-1 font-mono">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-400">Destination Account:</span>
                        <span className="text-white font-bold">{wth.accountDetails}</span>
                      </div>
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-400">Account Title:</span>
                        <span className="text-slate-200">{wth.accountTitle}</span>
                      </div>
                      {wth.referenceId && (
                        <div className="text-emerald-400 text-[10px]">
                          Payout TID: {wth.referenceId}
                        </div>
                      )}
                    </div>

                    {/* Actions */}
                    <div className="flex items-center justify-between pt-1">
                      <div>
                        {isPending ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-400">
                            <Clock className="w-3.5 h-3.5 animate-spin" />
                            <span>Pending Payout</span>
                          </span>
                        ) : isApproved ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Paid & Confirmed</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-400">
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Declined</span>
                          </span>
                        )}
                      </div>

                      {isPending && (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => approveWithdrawal(wth.id)}
                            className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-1 cursor-pointer"
                          >
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                            <span>Sent & Approve</span>
                          </button>
                          <button
                            onClick={() => rejectWithdrawal(wth.id)}
                            className="px-2.5 py-1.5 bg-rose-950 text-rose-300 border border-rose-800 hover:bg-rose-900 font-semibold text-xs rounded-lg flex items-center gap-1 cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                            <span>Reject</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* TAB 3: CLIENT ACCOUNTS LIST & ACCESS CONTROL */}
      {activeTab === 'investors' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl divide-y divide-slate-800/80 overflow-hidden">
          <div className="p-3 bg-slate-950 text-xs font-bold text-white flex justify-between items-center border-b border-slate-800">
            <span>Joined User Accounts ({allInvestors.length})</span>
            <span className="text-[10px] text-slate-400">Manage user access & block policy violators</span>
          </div>

          {Array.isArray(allInvestors) && allInvestors.map((inv) => {
            const isCurrent = inv.id === currentUser?.id;
            const isBlocked = inv.status === 'paused' || inv.status === 'blocked';
            const isAdminAccount = inv.phone === '03194815693' || (inv.email && inv.email.includes('farhan')) || inv.name.toLowerCase().includes('admin');

            return (
              <div
                key={inv.id}
                className={`p-3 sm:p-3.5 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  isBlocked ? 'bg-rose-950/20 border-l-4 border-l-rose-500' : 'hover:bg-slate-800/40'
                }`}
              >
                {/* Left: Avatar & User Details */}
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs shrink-0 ${
                    isBlocked ? 'bg-rose-950 border border-rose-500 text-rose-300' : 'bg-slate-800 text-amber-400'
                  }`}>
                    {inv.name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-xs sm:text-sm">
                        {inv.name}
                      </span>
                      {isBlocked ? (
                        <span className="bg-rose-950 text-rose-300 border border-rose-500/50 text-[9px] font-bold px-1.5 py-0.2 rounded-full flex items-center gap-0.5">
                          <XCircle className="w-2.5 h-2.5 text-rose-400" />
                          <span>BLOCKED</span>
                        </span>
                      ) : (
                        <span className="bg-emerald-950 text-emerald-400 border border-emerald-500/40 text-[9px] font-bold px-1.5 py-0.2 rounded-full flex items-center gap-0.5">
                          <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" />
                          <span>ACTIVE</span>
                        </span>
                      )}
                      {isCurrent && (
                        <span className="bg-amber-400 text-slate-950 text-[9px] font-bold px-1.5 py-0.2 rounded">
                          Selected
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono mt-0.5 space-x-2">
                      <span>Phone: <strong className="text-slate-200">{inv.phone || 'N/A'}</strong></span>
                      <span>·</span>
                      <span>Capital: <strong className="text-blue-400">{formatMoney(inv.capitalInvestedPKR)}</strong></span>
                      <span>·</span>
                      <span>Joined: {inv.joinedDate}</span>
                    </div>
                  </div>
                </div>

                {/* Right: Actions (View, Block, Unblock) */}
                <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                  <button
                    onClick={() => setCurrentUser(inv)}
                    disabled={isCurrent}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 text-xs rounded-lg transition-colors cursor-pointer"
                  >
                    {isCurrent ? 'Current' : 'View Account'}
                  </button>

                  {!isAdminAccount && (
                    isBlocked ? (
                      <button
                        onClick={() => unblockInvestor(inv.id)}
                        className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-1 shadow-sm"
                        title="Restore account access"
                      >
                        <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                        <span>Unblock Account</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => blockInvestor(inv.id)}
                        className="px-3 py-1 bg-rose-950 hover:bg-rose-900 border border-rose-800 text-rose-300 hover:text-white font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-1 shadow-sm"
                        title="Suspend account access for rule violations"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Block Account</span>
                      </button>
                    )
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* TAB 4: POST TRADE */}
      {activeTab === 'postTrade' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
          <h3 className="text-sm font-bold text-white">
            Publish Trade to Transparent Trading Journal
          </h3>

          {tradePosted ? (
            <div className="p-3 bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 text-xs rounded-xl flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400" />
              <span>Trade posted to public journal successfully!</span>
            </div>
          ) : (
            <form onSubmit={handlePostTrade} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-400 mb-1">Asset Pair</label>
                  <select
                    value={newPair}
                    onChange={(e) => setNewPair(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
                  >
                    <option value="XAU/USD (Gold)">XAU/USD (Gold)</option>
                    <option value="EUR/USD">EUR/USD</option>
                    <option value="GBP/JPY">GBP/JPY</option>
                    <option value="USOIL (Crude)">USOIL (Crude Oil)</option>
                    <option value="BTC/USDT">BTC/USDT</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Action</label>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() => setNewAction('BUY')}
                      className={`p-2 rounded-lg font-bold border ${
                        newAction === 'BUY'
                          ? 'bg-emerald-600 text-white border-emerald-500'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      BUY
                    </button>
                    <button
                      type="button"
                      onClick={() => setNewAction('SELL')}
                      className={`p-2 rounded-lg font-bold border ${
                        newAction === 'SELL'
                          ? 'bg-rose-600 text-white border-rose-500'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      SELL
                    </button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-400 mb-1">Entry Price</label>
                  <input
                    type="number"
                    step="0.001"
                    value={newEntry}
                    onChange={(e) => setNewEntry(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Exit Price</label>
                  <input
                    type="number"
                    step="0.001"
                    value={newExit}
                    onChange={(e) => setNewExit(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Profit %</label>
                  <input
                    type="number"
                    step="0.05"
                    value={newProfitPercent}
                    onChange={(e) => setNewProfitPercent(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-emerald-400 font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Trade Notes</label>
                <textarea
                  rows={2}
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-amber-400 text-slate-950 font-bold rounded-lg cursor-pointer flex items-center justify-center gap-1.5"
              >
                <PlusCircle className="w-4 h-4 stroke-[2.5]" />
                <span>Publish Trade</span>
              </button>
            </form>
          )}
        </div>
      )}
    </div>
  );
};
