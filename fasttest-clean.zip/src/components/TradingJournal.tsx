import React from 'react';
import { useApp } from '../context/AppContext';
import { TrendingUp, TrendingDown, Clock, ShieldCheck, Activity } from 'lucide-react';

export const TradingJournal: React.FC = () => {
  const { tradeLogs, formatMoney, language, t } = useApp();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-amber-400" />
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            {t('tradingJournalTitle')}
          </h2>
        </div>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          {t('tradingJournalSubtitle')}
        </p>
      </div>

      {/* Trade Cards Grid / Table */}
      <div className="grid grid-cols-1 gap-4">
        {tradeLogs.map((trade) => {
          const isBuy = trade.action === 'BUY';
          const isClosed = trade.status === 'CLOSED';

          return (
            <div
              key={trade.id}
              className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition-colors"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800/80">
                <div className="flex items-center gap-3">
                  <span
                    className={`px-2.5 py-1 rounded text-xs font-bold font-mono ${
                      isBuy
                        ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800/60'
                        : 'bg-rose-950/80 text-rose-400 border border-rose-800/60'
                    }`}
                  >
                    {trade.action}
                  </span>
                  <div>
                    <h3 className="text-base font-bold text-white">
                      {trade.assetPair}
                    </h3>
                    <span className="text-xs text-slate-400 font-mono">
                      {trade.date}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-4 sm:text-right">
                  <div>
                    <span className="text-[11px] text-slate-400 block">{language === 'ur' ? 'منافع فیصد' : 'Gain %'}</span>
                    <span className="text-sm font-bold font-mono tabular-nums text-emerald-400">
                      +{trade.profitPercentage}%
                    </span>
                  </div>

                  <div>
                    <span className="text-[11px] text-slate-400 block">{language === 'ur' ? 'کل پرافٹ' : 'Net Fund PnL'}</span>
                    <span className="text-sm font-bold font-mono tabular-nums text-emerald-400">
                      +{formatMoney(trade.pnlPKR)}
                    </span>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                      isClosed
                        ? 'bg-slate-800 text-slate-300'
                        : 'bg-amber-400/20 text-amber-300 border border-amber-400/40'
                    }`}
                  >
                    {trade.status === 'CLOSED'
                      ? (language === 'ur' ? 'مکمل شدہ (Closed)' : 'Closed')
                      : (language === 'ur' ? 'لائیو چل رہی ہے (Running)' : 'Live Position')}
                  </span>
                </div>
              </div>

              {/* Price Details */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4 text-xs">
                <div>
                  <span className="text-slate-400">{t('entry')}:</span>
                  <div className="text-sm font-bold font-mono text-white tabular-nums mt-0.5">
                    {trade.entryPrice.toLocaleString()}
                  </div>
                </div>
                <div>
                  <span className="text-slate-400">{t('exit')}:</span>
                  <div className="text-sm font-bold font-mono text-white tabular-nums mt-0.5">
                    {trade.exitPrice ? trade.exitPrice.toLocaleString() : '-- (Live)'}
                  </div>
                </div>
                <div className="col-span-2 sm:col-span-1">
                  <span className="text-slate-400">{t('notes')}:</span>
                  <p className="text-slate-300 text-xs mt-0.5 leading-relaxed">
                    {trade.notes}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
