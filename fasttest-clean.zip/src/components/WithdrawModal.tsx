import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Check, ArrowRight, Smartphone, CreditCard, Globe, Lock } from 'lucide-react';
import { WithdrawalRequest } from '../types';

export const WithdrawModal: React.FC = () => {
  const {
    isWithdrawModalOpen,
    setIsWithdrawModalOpen,
    setIsDepositModalOpen,
    currentUser,
    submitWithdrawalRequest,
    formatMoney,
    t
  } = useApp();

  const safeCurrentUser = currentUser || {
    id: '',
    name: '',
    phone: '',
    capitalInvestedPKR: 0,
    availableBalancePKR: 0,
    status: 'active'
  };

  const [amountPKR, setAmountPKR] = useState<number>(Math.min(500, safeCurrentUser.availableBalancePKR || 500));
  const [method, setMethod] = useState<WithdrawalRequest['paymentMethod']>('easypaisa');
  const [accountDetails, setAccountDetails] = useState<string>(safeCurrentUser.phone || '');
  const [accountTitle, setAccountTitle] = useState<string>(safeCurrentUser.name || '');
  const [submitted, setSubmitted] = useState<boolean>(false);

  if (!isWithdrawModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (amountPKR < 100) {
      alert('Minimum withdrawal amount is 100 PKR.');
      return;
    }

    if (amountPKR > (safeCurrentUser.availableBalancePKR || 0)) {
      alert('Requested amount exceeds available balance.');
      return;
    }

    if (!accountDetails.trim() || !accountTitle.trim()) {
      alert('Please enter receiving account details and account holder title.');
      return;
    }

    submitWithdrawalRequest(amountPKR, method, accountDetails, accountTitle);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setIsWithdrawModalOpen(false);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-7 my-8">
        <button
          onClick={() => setIsWithdrawModalOpen(false)}
          className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="py-10 text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/40">
              <Check className="w-8 h-8 stroke-[3]" />
            </div>
            <h3 className="text-xl font-bold text-white">
              Withdrawal Request Submitted!
            </h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
              Your payout request of Rs. {amountPKR.toLocaleString()} will be verified and sent directly to your {method === 'easypaisa' ? 'EasyPaisa' : method === 'paytm' ? 'Paytm / UPI' : 'PayPal'} account.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-white">
                {t('withdrawModalTitle')}
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                {t('withdrawModalSubtitle')}
              </p>
            </div>

            {/* Available Balance Callout */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 flex items-center justify-between">
              <div>
                <span className="text-[11px] text-slate-400 block">{t('availableWithdrawal')}</span>
                <span className="text-xl font-bold font-mono text-emerald-400 tabular-nums">
                  {formatMoney(safeCurrentUser.availableBalancePKR || 0)}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setAmountPKR(safeCurrentUser.availableBalancePKR || 0)}
                className="text-xs font-semibold text-amber-400 hover:text-amber-300 underline cursor-pointer"
              >
                Withdraw Full Balance
              </button>
            </div>

            {/* Amount */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <label className="font-semibold text-slate-300">
                  Withdrawal Amount (PKR)
                </label>
                <span className="text-slate-400 font-mono tabular-nums">
                  Min: 100 PKR
                </span>
              </div>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-mono font-bold">Rs.</span>
                <input
                  type="number"
                  min="100"
                  max={safeCurrentUser.availableBalancePKR || 100000}
                  step="50"
                  value={amountPKR}
                  onChange={(e) => setAmountPKR(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-12 pr-3 py-2 text-base font-mono font-bold text-white focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            {/* Payout Method (EasyPaisa, JazzCash, Paytm, PayPal) */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t('destinationMethod')}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {/* EasyPaisa */}
                <button
                  type="button"
                  onClick={() => setMethod('easypaisa')}
                  className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    method === 'easypaisa'
                      ? 'bg-emerald-950/60 border-emerald-500 ring-1 ring-emerald-500/30 text-white font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="w-7 h-7 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center shrink-0 mb-1.5">
                    <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                  <div>
                    <span className="block text-xs font-bold text-white">EasyPaisa</span>
                    <span className="text-[10px] text-emerald-400">Pakistan</span>
                  </div>
                </button>

                {/* JazzCash */}
                <button
                  type="button"
                  onClick={() => setMethod('jazzcash')}
                  className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    method === 'jazzcash'
                      ? 'bg-amber-950/60 border-amber-500 ring-1 ring-amber-500/30 text-white font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="w-7 h-7 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center shrink-0 mb-1.5">
                    <Smartphone className="w-3.5 h-3.5 text-amber-400" />
                  </div>
                  <div>
                    <span className="block text-xs font-bold text-white">JazzCash</span>
                    <span className="text-[10px] text-amber-400">Pakistan</span>
                  </div>
                </button>

                {/* Paytm */}
                <button
                  type="button"
                  onClick={() => setMethod('paytm')}
                  className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    method === 'paytm'
                      ? 'bg-sky-950/60 border-sky-500 ring-1 ring-sky-500/30 text-white font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="w-7 h-7 rounded-lg bg-sky-500/20 border border-sky-500/40 flex items-center justify-center shrink-0 mb-1.5">
                    <CreditCard className="w-3.5 h-3.5 text-sky-400" />
                  </div>
                  <div>
                    <span className="block text-xs font-bold text-white">Paytm / UPI</span>
                    <span className="text-[10px] text-sky-400">India</span>
                  </div>
                </button>

                {/* PayPal */}
                <button
                  type="button"
                  onClick={() => setMethod('paypal')}
                  className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    method === 'paypal'
                      ? 'bg-indigo-950/60 border-indigo-500 ring-1 ring-indigo-500/30 text-white font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="w-7 h-7 rounded-lg bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center shrink-0 mb-1.5">
                    <Globe className="w-3.5 h-3.5 text-indigo-400" />
                  </div>
                  <div>
                    <span className="block text-xs font-bold text-white">PayPal</span>
                    <span className="text-[10px] text-indigo-400">Global</span>
                  </div>
                </button>
              </div>
            </div>

            {/* Recipient Details */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {method === 'easypaisa'
                    ? 'EasyPaisa Mobile Number *'
                    : method === 'jazzcash'
                    ? 'JazzCash Mobile Number *'
                    : method === 'paytm'
                    ? 'Paytm UPI ID / Phone Number *'
                    : 'PayPal Email Address *'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={
                    method === 'easypaisa'
                      ? 'e.g. 0312-9876543'
                      : method === 'paytm'
                      ? 'e.g. user@paytm or 9876543210'
                      : 'e.g. your-email@gmail.com'
                  }
                  value={accountDetails}
                  onChange={(e) => setAccountDetails(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Account Holder Full Name (Account Title) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Full Name on Account"
                  value={accountTitle}
                  onChange={(e) => setAccountTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              Minimum withdrawal is 100 PKR. Daily payouts processed within 1-4 hours.
            </p>

            <button
              type="submit"
              disabled={(safeCurrentUser.availableBalancePKR || 0) < 100}
              className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 disabled:cursor-not-allowed text-slate-950 font-bold text-xs sm:text-sm rounded-lg shadow transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{t('submitWithdrawal')} (Rs. {amountPKR.toLocaleString()})</span>
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
