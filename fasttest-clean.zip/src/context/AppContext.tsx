import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import {
  Language,
  Currency,
  InvestmentPlan,
  Investor,
  DailyProfitRecord,
  TradeLog,
  DepositRequest,
  WithdrawalRequest,
  Transaction,
  UserAccount
} from '@/src/types';
import {
  INITIAL_PLANS,
  INITIAL_INVESTORS,
  INITIAL_DAILY_PROFITS,
  INITIAL_TRADE_LOGS,
  INITIAL_DEPOSIT_REQUESTS,
  INITIAL_WITHDRAWAL_REQUESTS,
  INITIAL_TRANSACTIONS,
  getDailyRoiRate,
  getExpectedDailyProfit
} from '@/src/data/mockData';
import { translations } from '../translations';

export const PKR_PER_USD = 280;
const API_BASE = '';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  currency: Currency;
  setCurrency: (curr: Currency) => void;
  currentRoleView: 'investor' | 'manager';
  setCurrentRoleView: (role: 'investor' | 'manager') => void;
  activeNavTab: string;
  setActiveNavTab: (tab: string) => void;

  currentUser: Investor | null;
  setCurrentUser: (user: Investor) => void;
  allInvestors: Investor[];
  plans: InvestmentPlan[];
  dailyProfits: DailyProfitRecord[];
  tradeLogs: TradeLog[];
  depositRequests: DepositRequest[];
  withdrawalRequests: WithdrawalRequest[];
  transactions: Transaction[];

  // Authentication
  isAuthenticated: boolean;
  currentAccount: UserAccount | null;
  isAdmin: boolean;
  login: (username: string, password: string) => { success: boolean; error?: string };
  register: (
    username: string,
    phone: string,
    password: string,
    referralCode?: string
  ) => { success: boolean; error?: string };
  logout: () => void;

  // Referral System (5 Qualified Referrals = Rs. 10,000 Bonus)
  referralLink: string;
  referralStats: {
    totalReferred: number;
    qualifiedCount: number;
    pendingCount: number;
    currentMilestoneProgress: number;
    remainingForBonus: number;
    totalBonusEarned: number;
    referredList: Array<{
      id: string;
      username: string;
      phone: string;
      joinedDate: string;
      capitalInvestedPKR: number;
      isQualified: boolean;
    }>;
  };

  formatMoney: (amountPKR: number) => string;
  t: (key: keyof typeof translations.en) => string;

  // Modals
  isDepositModalOpen: boolean;
  setIsDepositModalOpen: (open: boolean) => void;
  isWithdrawModalOpen: boolean;
  setIsWithdrawModalOpen: (open: boolean) => void;
  isDistributeModalOpen: boolean;
  setIsDistributeModalOpen: (open: boolean) => void;
  selectedPlanForDeposit: InvestmentPlan | null;
  setSelectedPlanForDeposit: (plan: InvestmentPlan | null) => void;

  // Actions
  submitDepositRequest: (
    planId: string,
    amountPKR: number,
    paymentMethod: DepositRequest['paymentMethod'],
    senderAccountNumber: string,
    transactionId: string,
    proofNote?: string
  ) => void;
  submitWithdrawalRequest: (
    amountPKR: number,
    paymentMethod: WithdrawalRequest['paymentMethod'],
    accountDetails: string,
    accountTitle: string
  ) => void;
  distributeDailyProfit: (
    profitRate: number,
    strategyName: string,
    primaryAsset: string,
    marketNotes: string
  ) => { totalDistributedPKR: number; investorsCount: number };
  approveDeposit: (depositId: string) => void;
  rejectDeposit: (depositId: string) => void;
  approveWithdrawal: (withdrawalId: string) => void;
  rejectWithdrawal: (withdrawalId: string) => void;
  blockInvestor: (investorId: string) => void;
  unblockInvestor: (investorId: string) => void;
  addTradeLog: (trade: Omit<TradeLog, 'id'>) => void;
  resetToDemoData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const INITIAL_ACCOUNTS: UserAccount[] = [
  {
    id: 'usr_01',
    username: 'investor',
    phone: '0300-1234567',
    password: 'password123',
    investorId: 'inv_user',
    createdAt: '2026-09-15'
  },
  {
    id: 'usr_admin',
    username: 'admin',
    phone: '03194815693',
    password: 'admin',
    investorId: 'inv_admin',
    createdAt: '2026-01-01'
  },
  {
    id: 'usr_admin2',
    username: 'zeeshantrader295@gmail.com',
    phone: '03194815693',
    password: 'admin',
    investorId: 'inv_admin',
    createdAt: '2026-01-01'
  }
];

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>('en');

  const [currency, setCurrencyState] = useState<Currency>(() => {
    return (localStorage.getItem('zt_curr') as Currency) || 'PKR';
  });

  // Authentication State
  const [registeredAccounts, setRegisteredAccounts] = useState<UserAccount[]>(() => {
    const saved = localStorage.getItem('zt_users_v2');
    return saved ? JSON.parse(saved) : INITIAL_ACCOUNTS;
  });

  const [currentAccount, setCurrentAccount] = useState<UserAccount | null>(() => {
    const saved = localStorage.getItem('zt_curr_account_v2');
    return saved ? JSON.parse(saved) : null;
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('zt_auth_v2') === 'true';
  });

  const isAdmin = Boolean(
    currentAccount &&
      (currentAccount.username.toLowerCase() === 'admin' ||
        currentAccount.username.toLowerCase() === 'farhan' ||
        currentAccount.username.toLowerCase() === 'zeeshantrader295@gmail.com')
  );

  const [currentRoleViewState, setCurrentRoleViewState] = useState<'investor' | 'manager'>('investor');
  const currentRoleView = isAdmin ? currentRoleViewState : 'investor';
  const setCurrentRoleView = (role: 'investor' | 'manager') => {
    if (role === 'manager' && !isAdmin) {
      setCurrentRoleViewState('investor');
      return;
    }
    setCurrentRoleViewState(role);
  };
  const [activeNavTab, setActiveNavTab] = useState<string>('dashboard');

  const [allInvestors, setAllInvestors] = useState<Investor[]>(() => {
    const saved = localStorage.getItem('zt_investors_v2');
    const data = saved ? JSON.parse(saved) : INITIAL_INVESTORS;
    return data.map((inv: Investor) => {
      if (inv.id === 'inv_admin') {
        return {
          ...inv,
          capitalInvestedPKR: 0,
          totalProfitEarnedPKR: 0,
          availableBalancePKR: 0,
          pendingWithdrawalPKR: 0
        };
      }
      return inv;
    });
  });

  const [currentUserId, setCurrentUserId] = useState<string>(() => {
    const savedAccount = localStorage.getItem('zt_curr_account_v2');
    if (savedAccount) {
      try {
        const parsed = JSON.parse(savedAccount);
        return parsed.investorId || 'inv_current';
      } catch (e) {
        return 'inv_current';
      }
    }
    return 'inv_current';
  });

  const [plans] = useState<InvestmentPlan[]>(INITIAL_PLANS);

  const [dailyProfits, setDailyProfits] = useState<DailyProfitRecord[]>(() => {
    const saved = localStorage.getItem('zt_daily_profits_v2');
    return saved ? JSON.parse(saved) : INITIAL_DAILY_PROFITS;
  });

  const [tradeLogs, setTradeLogs] = useState<TradeLog[]>(() => {
    const saved = localStorage.getItem('zt_trade_logs_v2');
    return saved ? JSON.parse(saved) : INITIAL_TRADE_LOGS;
  });

  const [depositRequests, setDepositRequests] = useState<DepositRequest[]>(() => {
    const saved = localStorage.getItem('zt_deposits_v2');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return parsed.filter((d: any) => !['dep_01', 'dep_02'].includes(d.id));
      } catch {
        return [];
      }
    }
    return INITIAL_DEPOSIT_REQUESTS;
  });

  const [withdrawalRequests, setWithdrawalRequests] = useState<WithdrawalRequest[]>(() => {
    const saved = localStorage.getItem('zt_withdrawals_v2');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return parsed.filter((w: any) => w.id !== 'wth_01');
      } catch {
        return [];
      }
    }
    return INITIAL_WITHDRAWAL_REQUESTS;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('zt_transactions_v2');
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  // Modals state
  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);
  const [isDistributeModalOpen, setIsDistributeModalOpen] = useState(false);
  const [selectedPlanForDeposit, setSelectedPlanForDeposit] = useState<InvestmentPlan | null>(null);

  // Sync state to LocalStorage
  useEffect(() => {
    localStorage.setItem('zt_lang', 'en');
    document.documentElement.dir = 'ltr';
    document.documentElement.lang = 'en';
  }, [language]);

  useEffect(() => {
    localStorage.setItem('zt_curr', currency);
  }, [currency]);

  useEffect(() => {
    localStorage.setItem('zt_investors_v2', JSON.stringify(allInvestors));
  }, [allInvestors]);

  useEffect(() => {
    localStorage.setItem('zt_daily_profits_v2', JSON.stringify(dailyProfits));
  }, [dailyProfits]);

  useEffect(() => {
    localStorage.setItem('zt_trade_logs_v2', JSON.stringify(tradeLogs));
  }, [tradeLogs]);

  useEffect(() => {
    localStorage.setItem('zt_deposits_v2', JSON.stringify(depositRequests));
  }, [depositRequests]);

  useEffect(() => {
    localStorage.setItem('zt_withdrawals_v2', JSON.stringify(withdrawalRequests));
  }, [withdrawalRequests]);

  useEffect(() => {
    localStorage.setItem('zt_transactions_v2', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('zt_users_v2', JSON.stringify(registeredAccounts));
  }, [registeredAccounts]);

  useEffect(() => {
    localStorage.setItem('zt_auth_v2', isAuthenticated ? 'true' : 'false');
    if (currentAccount) {
      localStorage.setItem('zt_curr_account_v2', JSON.stringify(currentAccount));
    } else {
      localStorage.removeItem('zt_curr_account_v2');
    }
  }, [isAuthenticated, currentAccount]);

  // Live Server Synchronization with Backend API
  const syncWithServer = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/state?t=${Date.now()}`);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.accounts)) setRegisteredAccounts(data.accounts);
        if (Array.isArray(data.investors) && data.investors.length > 0) setAllInvestors(data.investors);
        if (Array.isArray(data.depositRequests)) setDepositRequests(data.depositRequests);
        if (Array.isArray(data.withdrawalRequests)) setWithdrawalRequests(data.withdrawalRequests);
        if (Array.isArray(data.transactions)) setTransactions(data.transactions);
        if (Array.isArray(data.tradeLogs)) setTradeLogs(data.tradeLogs);
        if (Array.isArray(data.dailyProfits)) setDailyProfits(data.dailyProfits);
      } else {
        console.error('Sync failed, status:', res.status);
      }
    } catch (err) {
      console.error('Sync network error:', err);
    }
  };

  useEffect(() => {
    syncWithServer();
    const interval = setInterval(syncWithServer, 1000); // Faster polling: 1 second
    return () => clearInterval(interval);
  }, []);

  const login = (username: string, password: string): { success: boolean; error?: string } => {
    const cleanUsername = username.trim().toLowerCase();
    const cleanPassword = password.trim();

    // Check if logging in as admin
    const isAdminCred =
      (cleanUsername === 'admin' ||
        cleanUsername === 'farhan' ||
        cleanUsername === 'zeeshantrader295@gmail.com') &&
      cleanPassword === 'admin';

    let user = registeredAccounts.find(
      (acc) =>
        (acc.username.toLowerCase() === cleanUsername || acc.phone.replace(/[^0-9]/g, '') === cleanUsername.replace(/[^0-9]/g, '')) &&
        acc.password === cleanPassword
    );

    if (!user && isAdminCred) {
      user = {
        id: 'usr_admin',
        username: cleanUsername,
        phone: '03194815693',
        password: 'admin',
        investorId: 'inv_current',
        createdAt: '2026-01-01'
      };
    }

    if (!user) {
      // Async server fallback in background for other devices
      fetch(`${API_BASE}/api/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: cleanUsername, password: cleanPassword })
      })
        .then((res) => res.json())
        .then((resData) => {
          if (resData.success && resData.account) {
            setCurrentAccount(resData.account);
            setIsAuthenticated(true);
            setCurrentUserId(resData.account.investorId);
            if (resData.isAdmin) {
              setCurrentRoleViewState('manager');
            } else {
              setCurrentRoleViewState('investor');
            }
          }
        })
        .catch(() => {});

      return {
        success: false,
        error: language === 'ur' ? 'یوزر نیم یا پاسورڈ درست نہیں ہے۔' : 'Invalid username or password.'
      };
    }

    const targetInv = allInvestors.find((inv) => inv.id === user.investorId);
    const isAdminUser = cleanUsername === 'admin' || cleanUsername === 'farhan' || cleanUsername === 'zeeshantrader295@gmail.com';

    if (targetInv && (targetInv.status === 'paused' || targetInv.status === 'blocked') && !isAdminUser) {
      return {
        success: false,
        error: 'آپ کا اکاؤنٹ انتظامیہ کی طرف سے بلاک / معطل کر دیا گیا ہے۔ رہنمائی کے لیے ٹیلیگرام سپورٹ سے رابطہ کریں۔'
      };
    }

    setCurrentAccount(user);
    setIsAuthenticated(true);
    setCurrentUserId(user.investorId);
    if (isAdminUser) {
      setCurrentRoleViewState('manager');
    } else {
      setCurrentRoleViewState('investor');
    }
    return { success: true };
  };

  const register = (
    username: string,
    phone: string,
    password: string,
    referralCode?: string
  ): { success: boolean; error?: string } => {
    const cleanUsername = username.trim().toLowerCase();
    const cleanPhone = phone.trim();
    const cleanPassword = password.trim();
    const cleanRef = referralCode ? referralCode.trim().toLowerCase() : '';

    if (!cleanUsername || cleanUsername.length < 3) {
      return {
        success: false,
        error: language === 'ur' ? 'یوزر نیم کم از کم 3 حروف پر مشتمل ہونا چاہیے۔' : 'Username must be at least 3 characters.'
      };
    }

    if (!cleanPhone || cleanPhone.replace(/[^0-9]/g, '').length < 10) {
      return {
        success: false,
        error: language === 'ur' ? 'درست موبائل نمبر درج کریں (مثلاً 03123456789)۔' : 'Please enter a valid mobile number (e.g. 03123456789).'
      };
    }

    if (!cleanPassword || cleanPassword.length < 4) {
      return {
        success: false,
        error: language === 'ur' ? 'پاسورڈ کم از کم 4 ہندسوں یا حروف کا ہونا چاہیے۔' : 'Password must be at least 4 characters.'
      };
    }

    const exists = registeredAccounts.some(
      (acc) =>
        acc.username.toLowerCase() === cleanUsername ||
        acc.phone.replace(/[^0-9]/g, '') === cleanPhone.replace(/[^0-9]/g, '')
    );

    if (exists) {
      return {
        success: false,
        error: language === 'ur' ? 'یہ یوزر نیم یا فون نمبر پہلے سے موجود ہے۔ براہ کرم لاگ ان کریں۔' : 'This username or mobile number is already registered.'
      };
    }

    const newInvestorId = `inv_${Date.now()}`;
    const newInvestor: Investor = {
      id: newInvestorId,
      name: username.trim(),
      email: `${cleanUsername}@fasttestprofit.pk`,
      phone: cleanPhone,
      city: 'Pakistan',
      activePlanId: '',
      capitalInvestedPKR: 0,
      totalProfitEarnedPKR: 0,
      availableBalancePKR: 0,
      pendingWithdrawalPKR: 0,
      joinedDate: new Date().toISOString().split('T')[0],
      status: 'active',
      referralCode: cleanUsername,
      referredByCode: cleanRef,
      totalReferralEarningsPKR: 0,
      totalReferredUsersCount: 0,
      awardedBonusMilestones: 0
    };

    const newAccount: UserAccount = {
      id: `usr_${Date.now()}`,
      username: username.trim(),
      phone: cleanPhone,
      password: cleanPassword,
      investorId: newInvestorId,
      referredBy: cleanRef,
      createdAt: new Date().toISOString().split('T')[0]
    };

    // If referralCode was provided, update referrer count and check 5-member milestone
    if (cleanRef) {
      setAllInvestors((prev) =>
        prev.map((i) => {
          const isReferrer =
            i.name.toLowerCase() === cleanRef ||
            i.id.toLowerCase() === cleanRef ||
            (i.referralCode && i.referralCode.toLowerCase() === cleanRef);

          if (isReferrer) {
            const newCount = (i.totalReferredUsersCount || 0) + 1;
            const currentMilestones = i.awardedBonusMilestones || 0;
            const targetMilestones = Math.floor(newCount / 5);

            if (targetMilestones > currentMilestones) {
              const bonusAmount = (targetMilestones - currentMilestones) * 3000;
              const nowTimeStr = new Date().toISOString().replace('T', ' ').substring(0, 16);

              setTransactions((txPrev) => [
                {
                  id: `tx_ref_bonus_${Date.now()}_${i.id}`,
                  investorId: i.id,
                  type: 'PROFIT',
                  amountPKR: bonusAmount,
                  descriptionEn: `🎁 Referral Reward: 5 Members Invited! (+Rs. ${bonusAmount.toLocaleString()} Cash Bonus Credited)`,
                  descriptionUr: `🎁 ریفرل انعام: 5 ممبرز جوڑنے پر ${bonusAmount.toLocaleString()} روپے کیش بونس اکاؤنٹ میں شامل!`,
                  date: nowTimeStr,
                  status: 'COMPLETED'
                },
                ...txPrev
              ]);

              return {
                ...i,
                totalReferredUsersCount: newCount,
                awardedBonusMilestones: targetMilestones,
                totalReferralEarningsPKR: (i.totalReferralEarningsPKR || 0) + bonusAmount,
                availableBalancePKR: (i.availableBalancePKR || 0) + bonusAmount,
                totalProfitEarnedPKR: (i.totalProfitEarnedPKR || 0) + bonusAmount
              };
            }

            return { ...i, totalReferredUsersCount: newCount };
          }
          return i;
        })
      );
    }

    setAllInvestors((prev) => [newInvestor, ...prev]);
    setRegisteredAccounts((prev) => [...prev, newAccount]);
    setCurrentAccount(newAccount);
    setCurrentUserId(newInvestorId);
    setIsAuthenticated(true);
    setCurrentRoleViewState('investor');

    // Register on server database immediately so all devices receive it
    fetch(`${API_BASE}/api/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: username.trim(),
        phone: cleanPhone,
        password: cleanPassword,
        investorId: newInvestorId,
        accountId: newAccount.id,
        referralCode: cleanRef
      })
    })
      .then(() => syncWithServer())
      .catch(() => {});

    return { success: true };
  };

  const logout = () => {
    setIsAuthenticated(false);
    setCurrentAccount(null);
    setCurrentUserId('');
    localStorage.removeItem('zt_curr_account_v2');
    localStorage.removeItem('zt_auth_v2');
  };

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const setCurrency = (curr: Currency) => {
    setCurrencyState(curr);
  };

  const currentUser: Investor | null = useMemo(() => {
    if (!isAuthenticated || !currentAccount) return null;
    const byId = allInvestors.find((inv) => inv.id === currentUserId);
    if (byId) return byId;
    const byAccountInvId = allInvestors.find((inv) => inv.id === currentAccount.investorId);
    if (byAccountInvId) return byAccountInvId;
    const byName = allInvestors.find(
      (inv) => inv.name.toLowerCase() === currentAccount.username.toLowerCase()
    );
    if (byName) return byName;
    return {
      id: currentAccount.investorId || currentUserId || 'inv_fresh',
      name: currentAccount.username,
      email: `${currentAccount.username}@fasttestprofit.pk`,
      phone: currentAccount.phone || '',
      city: 'Pakistan',
      activePlanId: '',
      capitalInvestedPKR: 0,
      totalProfitEarnedPKR: 0,
      availableBalancePKR: 0,
      pendingWithdrawalPKR: 0,
      joinedDate: currentAccount.createdAt || new Date().toISOString().split('T')[0],
      status: 'active'
    };
  }, [isAuthenticated, currentAccount, currentUserId, allInvestors]);

  const setCurrentUser = (user: Investor) => {
    setCurrentUserId(user.id);
  };

  const t = (key: keyof typeof translations.en): string => {
    return translations.en[key] || String(key);
  };

  const formatMoney = (amountPKR: number): string => {
    if (currency === 'USD') {
      const usd = amountPKR / PKR_PER_USD;
      return `$${usd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
    const val = Math.round(amountPKR);
    return `Rs. ${val.toLocaleString('en-US')}`;
  };

  // Referral Link & Live Milestones (5 Qualified Referrals >= Rs. 3,000 = Rs. 10,000 Bonus)
  const referralCode = currentAccount?.username || '';
  const referralLink = `https://fasttestprofit100.netlify.app/?ref=${encodeURIComponent(referralCode)}`;

  const referralStats = useMemo(() => {
    if (!currentAccount) {
      return {
        totalReferred: 0,
        qualifiedCount: 0,
        pendingCount: 0,
        currentMilestoneProgress: 0,
        remainingForBonus: 5,
        totalBonusEarned: 0,
        referredList: []
      };
    }

    const myCode = currentAccount.username.toLowerCase();
    const myId = currentAccount.investorId;

    const map = new Map<
      string,
      {
        id: string;
        username: string;
        phone: string;
        joinedDate: string;
        capitalInvestedPKR: number;
        isQualified: boolean;
      }
    >();

    registeredAccounts.forEach((acc) => {
      if (acc.referredBy && (acc.referredBy.toLowerCase() === myCode || acc.referredBy.toLowerCase() === myId)) {
        const inv = allInvestors.find(
          (i) => i.id === acc.investorId || i.name.toLowerCase() === acc.username.toLowerCase()
        );
        const capital = inv ? inv.capitalInvestedPKR || 0 : 0;
        map.set(acc.username.toLowerCase(), {
          id: acc.id,
          username: acc.username,
          phone: acc.phone,
          joinedDate: acc.createdAt,
          capitalInvestedPKR: capital,
          isQualified: capital >= 3000
        });
      }
    });

    allInvestors.forEach((inv) => {
      if (
        inv.referredByCode &&
        (inv.referredByCode.toLowerCase() === myCode || inv.referredByCode.toLowerCase() === myId)
      ) {
        if (!map.has(inv.name.toLowerCase())) {
          const capital = inv.capitalInvestedPKR || 0;
          map.set(inv.name.toLowerCase(), {
            id: inv.id,
            username: inv.name,
            phone: inv.phone,
            joinedDate: inv.joinedDate,
            capitalInvestedPKR: capital,
            isQualified: capital >= 3000
          });
        }
      }
    });

    const referredList = Array.from(map.values());
    const totalReferred = referredList.length;
    const qualifiedCount = referredList.filter((r) => r.isQualified).length;
    const pendingCount = totalReferred - qualifiedCount;
    const currentMilestoneProgress = qualifiedCount % 5;
    const remainingForBonus = currentMilestoneProgress === 0 && qualifiedCount > 0 ? 0 : 5 - currentMilestoneProgress;
    const totalBonusEarned = Math.floor(qualifiedCount / 5) * 3000;

    return {
      totalReferred,
      qualifiedCount,
      pendingCount,
      currentMilestoneProgress,
      remainingForBonus,
      totalBonusEarned,
      referredList
    };
  }, [currentAccount, registeredAccounts, allInvestors]);

  // Actions
  const submitDepositRequest = (
    planId: string,
    amountPKR: number,
    paymentMethod: DepositRequest['paymentMethod'],
    senderAccountNumber: string,
    transactionId: string,
    proofNote?: string
  ) => {
    if (!currentUser) return;
    const newDeposit: DepositRequest = {
      id: `dep_${Date.now()}`,
      investorId: currentUser.id,
      investorName: currentUser.name,
      planId,
      amountPKR,
      paymentMethod,
      senderAccountNumber,
      transactionId,
      status: 'pending',
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
      adminNote: proofNote
    };

    setDepositRequests((prev) => [newDeposit, ...prev]);

    const newTx: Transaction = {
      id: `tx_${Date.now()}`,
      investorId: currentUser.id,
      type: 'DEPOSIT',
      paymentMethod,
      referenceId: transactionId,
      amountPKR,
      descriptionEn: `Deposit of Rs. ${amountPKR.toLocaleString()} via ${paymentMethod === 'easypaisa' ? 'EasyPaisa' : paymentMethod === 'paytm' ? 'Paytm / UPI' : 'PayPal'} (Ref: ${transactionId}) - Pending Admin Verification`,
      descriptionUr: `Deposit of Rs. ${amountPKR.toLocaleString()} via ${paymentMethod === 'easypaisa' ? 'EasyPaisa' : paymentMethod === 'paytm' ? 'Paytm / UPI' : 'PayPal'} (Ref: ${transactionId})`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'PENDING'
    };

    setTransactions((prev) => [newTx, ...prev]);

    // Send to backend server database so admin sees it immediately across devices
    fetch(`${API_BASE}/api/deposits`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        planId,
        amountPKR,
        paymentMethod,
        senderAccountNumber,
        transactionId,
        proofNote,
        investorId: currentUser.id,
        investorName: currentUser.name
      })
    })
      .then((res) => {
        if (!res.ok) console.error('Deposit submission failed status:', res.status);
        return syncWithServer();
      })
      .catch((err) => console.error('Deposit submission network error:', err));
  };

  const submitWithdrawalRequest = (
    amountPKR: number,
    paymentMethod: WithdrawalRequest['paymentMethod'],
    accountDetails: string,
    accountTitle: string
  ) => {
    if (!currentUser) return;
    if (amountPKR > currentUser.availableBalancePKR) {
      alert(language === 'ur' ? 'آپ کے اکاؤنٹ میں مطلوبہ بیلنس دستیاب نہیں ہے۔' : 'Insufficient available balance.');
      return;
    }

    const newWithdrawal: WithdrawalRequest = {
      id: `wth_${Date.now()}`,
      investorId: currentUser.id,
      investorName: currentUser.name,
      amountPKR,
      paymentMethod,
      accountDetails,
      accountTitle,
      status: 'pending',
      requestedAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };

    setWithdrawalRequests((prev) => [newWithdrawal, ...prev]);

    // Lock requested funds in pending
    setAllInvestors((prev) =>
      prev.map((inv) => {
        if (inv.id === currentUser.id) {
          return {
            ...inv,
            availableBalancePKR: inv.availableBalancePKR - amountPKR,
            pendingWithdrawalPKR: inv.pendingWithdrawalPKR + amountPKR
          };
        }
        return inv;
      })
    );

    const newTx: Transaction = {
      id: `tx_${Date.now()}`,
      investorId: currentUser.id,
      type: 'WITHDRAWAL',
      paymentMethod,
      referenceId: newWithdrawal.id,
      amountPKR,
      descriptionEn: `Withdrawal request for Rs. ${amountPKR.toLocaleString()} to ${accountTitle} (${accountDetails})`,
      descriptionUr: `${amountPKR.toLocaleString()} روپے نکالنے کی درخواست برائے ${accountTitle}`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'PENDING'
    };

    setTransactions((prev) => [newTx, ...prev]);

    // Send to backend server database so admin receives real-time online withdrawal request
    fetch(`${API_BASE}/api/withdrawals`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        amountPKR,
        paymentMethod,
        accountDetails,
        accountTitle,
        investorId: currentUser.id,
        investorName: currentUser.name
      })
    })
      .then((res) => {
        if (!res.ok) console.error('Withdrawal submission failed status:', res.status);
        return syncWithServer();
      })
      .catch((err) => console.error('Withdrawal submission network error:', err));
  };

  // Fund Admin: Distribute daily profit to active investors in PKR
  const distributeDailyProfit = (
    profitRate: number,
    strategyName: string,
    primaryAsset: string,
    marketNotes: string
  ) => {
    let totalDistributed = 0;
    const todayStr = new Date().toISOString().split('T')[0];
    const nowTimeStr = new Date().toISOString().replace('T', ' ').substring(0, 16);

    const newProfitsList: DailyProfitRecord[] = [];
    const newTxList: Transaction[] = [];

    const updatedInvestors = allInvestors.map((inv) => {
      if (inv.capitalInvestedPKR > 0 && inv.status === 'active') {
        const profitAmount = Math.round((inv.capitalInvestedPKR * profitRate) / 100);
        totalDistributed += profitAmount;

        newProfitsList.push({
          id: `dp_${Date.now()}_${inv.id}`,
          investorId: inv.id,
          investorName: inv.name,
          date: todayStr,
          returnPercentage: profitRate,
          amountPKR: profitAmount,
          strategyName: strategyName || 'London & NY Session Alpha',
          tradePair: primaryAsset || 'XAU/USD',
          status: 'credited'
        });

        newTxList.push({
          id: `tx_${Date.now()}_${inv.id}`,
          investorId: inv.id,
          type: 'PROFIT',
          amountPKR: profitAmount,
          descriptionEn: `Daily profit (${profitRate}%) of Rs. ${profitAmount.toLocaleString()} credited`,
          descriptionUr: `روزانہ منافع (${profitRate}%) مالیت ${profitAmount.toLocaleString()} روپے جمع کر دیا گیا`,
          date: nowTimeStr,
          status: 'COMPLETED'
        });

        return {
          ...inv,
          totalProfitEarnedPKR: inv.totalProfitEarnedPKR + profitAmount,
          availableBalancePKR: inv.availableBalancePKR + profitAmount
        };
      }
      return inv;
    });

    setAllInvestors(updatedInvestors);
    setDailyProfits((prev) => [...newProfitsList, ...prev]);
    setTransactions((prev) => [...newTxList, ...prev]);

    // Auto-log matching trade in journal
    const newTrade: TradeLog = {
      id: `tl_${Date.now()}`,
      date: nowTimeStr,
      assetPair: primaryAsset || 'XAU/USD (Gold)',
      action: 'BUY',
      entryPrice: 2742.0,
      exitPrice: 2761.5,
      profitPercentage: profitRate,
      pnlPKR: Math.round(totalDistributed * 1.5),
      notes: marketNotes || `${strategyName} executed with discipline. Profit distributed to all investors.`,
      status: 'CLOSED'
    };

    setTradeLogs((prev) => [newTrade, ...prev]);

    // Distribute on backend server
    fetch(`${API_BASE}/api/distribute-profit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        profitRate,
        strategyName,
        primaryAsset,
        marketNotes
      })
    }).then(() => syncWithServer()).catch(() => {});

    return {
      totalDistributedPKR: totalDistributed,
      investorsCount: newProfitsList.length
    };
  };

  const approveDeposit = (depositId: string) => {
    const dep = depositRequests.find((d) => d.id === depositId);
    if (!dep) return;

    const roiPercent = getDailyRoiRate(dep.amountPKR);
    const firstProfitAmount = getExpectedDailyProfit(dep.amountPKR);
    const now = Date.now();
    const nowTimeStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const todayStr = new Date().toISOString().split('T')[0];

    setDepositRequests((prev) =>
      prev.map((d) => (d.id === depositId ? { ...d, status: 'approved' } : d))
    );

    setAllInvestors((prev) =>
      prev.map((inv) => {
        if (inv.id === dep.investorId) {
          return {
            ...inv,
            capitalInvestedPKR: (inv.capitalInvestedPKR || 0) + dep.amountPKR,
            availableBalancePKR: (inv.availableBalancePKR || 0) + firstProfitAmount, // Withdrawable first profit
            totalProfitEarnedPKR: (inv.totalProfitEarnedPKR || 0) + firstProfitAmount,
            activePlanId: dep.planId || inv.activePlanId,
            lastApprovedDepositAt: now,
            lastProfitTimestamp: now,
            nextProfitTimestamp: now + 24 * 60 * 60 * 1000
          };
        }
        return inv;
      })
    );

    // Update deposit transaction
    setTransactions((prev) => [
      {
        id: `tx_first_profit_${Date.now()}`,
        investorId: dep.investorId,
        type: 'PROFIT',
        amountPKR: firstProfitAmount,
        descriptionEn: `First Day 24h Profit (+${roiPercent}% = Rs. ${firstProfitAmount.toLocaleString()}) Credited upon Deposit Approval (Withdrawable)`,
        descriptionUr: `پہلے دن کا منافع (+${roiPercent}% = ${firstProfitAmount.toLocaleString()} روپے) منظور ہوتے ہی بیلنس میں شامل (فوری وڈرا کے لیے تیار)`,
        date: nowTimeStr,
        status: 'COMPLETED'
      },
      ...prev.map((tx) => {
        if (tx.investorId === dep.investorId && tx.type === 'DEPOSIT' && tx.status === 'PENDING') {
          return {
            ...tx,
            status: 'COMPLETED' as const,
            descriptionEn: `Deposit of Rs. ${dep.amountPKR.toLocaleString()} APPROVED & ACTIVATED (Ref: ${dep.transactionId})`,
            descriptionUr: `Deposit of Rs. ${dep.amountPKR.toLocaleString()} APPROVED & ACTIVATED`
          };
        }
        return tx;
      })
    ]);

    setDailyProfits((prev) => [
      {
        id: `dp_first_${Date.now()}_${dep.investorId}`,
        investorId: dep.investorId,
        investorName: dep.investorName,
        date: todayStr,
        returnPercentage: roiPercent,
        amountPKR: firstProfitAmount,
        strategyName: 'Instant Day 1 Profit (24h Real Cycle Active)',
        tradePair: 'XAU/USD (Gold)',
        status: 'credited'
      },
      ...prev
    ]);

    // Call backend API to approve and persist across sessions
    fetch(`${API_BASE}/api/deposits/${depositId}/approve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }).then(() => syncWithServer()).catch(() => {});
  };

  const rejectDeposit = (depositId: string) => {
    const dep = depositRequests.find((d) => d.id === depositId);
    if (!dep) return;

    setDepositRequests((prev) =>
      prev.map((d) => (d.id === depositId ? { ...d, status: 'rejected' } : d))
    );

    setTransactions((prev) =>
      prev.map((tx) => {
        if (tx.investorId === dep.investorId && tx.type === 'DEPOSIT' && tx.status === 'PENDING') {
          return {
            ...tx,
            status: 'REJECTED',
            descriptionEn: `Deposit of Rs. ${dep.amountPKR.toLocaleString()} declined by Admin (Invalid TID/Proof)`,
            descriptionUr: `${dep.amountPKR.toLocaleString()} روپے کا ڈپازٹ ایڈمن کی طرف سے مسترد کر دیا گیا`
          };
        }
        return tx;
      })
    );

    fetch(`${API_BASE}/api/deposits/${depositId}/reject`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }).then(() => syncWithServer()).catch(() => {});
  };

  const approveWithdrawal = (withdrawalId: string) => {
    const wth = withdrawalRequests.find((w) => w.id === withdrawalId);
    if (!wth) return;

    setWithdrawalRequests((prev) =>
      prev.map((w) =>
        w.id === withdrawalId
          ? {
              ...w,
              status: 'approved',
              processedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
              referenceId: `EP-REF-${Math.floor(100000 + Math.random() * 900000)}`
            }
          : w
      )
    );

    setAllInvestors((prev) =>
      prev.map((inv) => {
        if (inv.id === wth.investorId) {
          return {
            ...inv,
            pendingWithdrawalPKR: Math.max(0, inv.pendingWithdrawalPKR - wth.amountPKR)
          };
        }
        return inv;
      })
    );

    setTransactions((prev) =>
      prev.map((tx) => {
        if (tx.investorId === wth.investorId && tx.type === 'WITHDRAWAL' && tx.status === 'PENDING') {
          return {
            ...tx,
            status: 'COMPLETED',
            descriptionEn: `Withdrawal of Rs. ${wth.amountPKR.toLocaleString()} APPROVED & TRANSFERRED via ${wth.paymentMethod.toUpperCase()} to ${wth.accountTitle}`,
            descriptionUr: `Withdrawal of Rs. ${wth.amountPKR.toLocaleString()} APPROVED & TRANSFERRED`
          };
        }
        return tx;
      })
    );

    fetch(`${API_BASE}/api/withdrawals/${withdrawalId}/approve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }).then(() => syncWithServer()).catch(() => {});
  };

  const rejectWithdrawal = (withdrawalId: string) => {
    const wth = withdrawalRequests.find((w) => w.id === withdrawalId);
    if (!wth) return;

    setWithdrawalRequests((prev) =>
      prev.map((w) => (w.id === withdrawalId ? { ...w, status: 'rejected' } : w))
    );

    // Refund pending withdrawal back to available balance
    setAllInvestors((prev) =>
      prev.map((inv) => {
        if (inv.id === wth.investorId) {
          return {
            ...inv,
            availableBalancePKR: inv.availableBalancePKR + wth.amountPKR,
            pendingWithdrawalPKR: Math.max(0, inv.pendingWithdrawalPKR - wth.amountPKR)
          };
        }
        return inv;
      })
    );

    setTransactions((prev) =>
      prev.map((tx) => {
        if (tx.investorId === wth.investorId && tx.type === 'WITHDRAWAL' && tx.status === 'PENDING') {
          return {
            ...tx,
            status: 'REJECTED',
            descriptionEn: `Withdrawal of Rs. ${wth.amountPKR.toLocaleString()} REJECTED & REFUNDED by Admin`,
            descriptionUr: `Withdrawal of Rs. ${wth.amountPKR.toLocaleString()} REJECTED & REFUNDED`
          };
        }
        return tx;
      })
    );

    fetch(`${API_BASE}/api/withdrawals/${withdrawalId}/reject`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }).then(() => syncWithServer()).catch(() => {});
  };

  const blockInvestor = (investorId: string) => {
    setAllInvestors((prev) =>
      prev.map((inv) => (inv.id === investorId ? { ...inv, status: 'paused' as const } : inv))
    );
    fetch(`${API_BASE}/api/investors/${investorId}/block`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }).then(() => syncWithServer()).catch(() => {});
  };

  const unblockInvestor = (investorId: string) => {
    setAllInvestors((prev) =>
      prev.map((inv) => (inv.id === investorId ? { ...inv, status: 'active' as const } : inv))
    );
    fetch(`${API_BASE}/api/investors/${investorId}/unblock`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }).then(() => syncWithServer()).catch(() => {});
  };

  const addTradeLog = (trade: Omit<TradeLog, 'id'>) => {
    const newTrade: TradeLog = {
      ...trade,
      id: `tl_${Date.now()}`
    };
    setTradeLogs((prev) => [newTrade, ...prev]);
  };

  const resetToDemoData = () => {
    localStorage.removeItem('zt_investors_v2');
    localStorage.removeItem('zt_daily_profits_v2');
    localStorage.removeItem('zt_trade_logs_v2');
    localStorage.removeItem('zt_deposits_v2');
    localStorage.removeItem('zt_withdrawals_v2');
    localStorage.removeItem('zt_transactions_v2');
    setAllInvestors(INITIAL_INVESTORS);
    setDailyProfits(INITIAL_DAILY_PROFITS);
    setTradeLogs(INITIAL_TRADE_LOGS);
    setDepositRequests(INITIAL_DEPOSIT_REQUESTS);
    setWithdrawalRequests(INITIAL_WITHDRAWAL_REQUESTS);
    setTransactions(INITIAL_TRANSACTIONS);
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        currency,
        setCurrency,
        currentRoleView,
        setCurrentRoleView,
        activeNavTab,
        setActiveNavTab,
        currentUser,
        setCurrentUser,
        allInvestors,
        plans,
        dailyProfits,
        tradeLogs,
        depositRequests,
        withdrawalRequests,
        transactions,
        isAuthenticated,
        currentAccount,
        isAdmin,
        login,
        register,
        logout,
        referralLink,
        referralStats,
        formatMoney,
        t,
        isDepositModalOpen,
        setIsDepositModalOpen,
        isWithdrawModalOpen,
        setIsWithdrawModalOpen,
        isDistributeModalOpen,
        setIsDistributeModalOpen,
        selectedPlanForDeposit,
        setSelectedPlanForDeposit,
        submitDepositRequest,
        submitWithdrawalRequest,
        distributeDailyProfit,
        approveDeposit,
        rejectDeposit,
        approveWithdrawal,
        rejectWithdrawal,
        blockInvestor,
        unblockInvestor,
        addTradeLog,
        resetToDemoData
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
