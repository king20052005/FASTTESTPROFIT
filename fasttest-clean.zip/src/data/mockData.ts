import {
  InvestmentPlan,
  Investor,
  DailyProfitRecord,
  TradeLog,
  DepositRequest,
  WithdrawalRequest,
  Transaction
} from '../types';

export const OFFICIAL_PAYMENT_ACCOUNTS = {
  easypaisa: {
    accountNumber: '03194815693',
    accountTitle: 'Farhan',
    network: 'EasyPaisa Pakistan',
    instructionsEn: 'Send funds to official EasyPaisa: 03194815693 (Title: Farhan). Enter 11-digit TID from 3737 SMS below.',
    instructionsUr: 'Send funds to official EasyPaisa: 03194815693 (Title: Farhan). Enter 11-digit TID from 3737 SMS below.'
  },
  jazzcash: {
    accountNumber: '03194815693',
    accountTitle: 'Farhan',
    network: 'JazzCash Pakistan',
    instructionsEn: 'Send funds to official JazzCash: 03194815693 (Title: Farhan). Enter 11-digit TID from 8558 SMS below.',
    instructionsUr: 'Send funds to official JazzCash: 03194815693 (Title: Farhan). Enter 11-digit TID from 8558 SMS below.'
  },
  paytm: {
    accountNumber: 'fasttestprofit@paytm',
    accountTitle: 'FASTTEST Official (Paytm / UPI India)',
    network: 'Paytm India (UPI & Wallet)',
    instructionsEn: 'Transfer funds via Paytm or UPI ID: fasttestprofit@paytm (Title: FASTTEST Official). Enter the 12-digit UPI / Order Ref ID below.',
    instructionsUr: 'Transfer funds via Paytm or UPI ID: fasttestprofit@paytm (Title: FASTTEST Official). Enter the 12-digit UPI / Order Ref ID below.'
  },
  paypal: {
    accountNumber: 'payments@fasttestprofit.com',
    accountTitle: 'FASTTEST Global (PayPal)',
    network: 'PayPal International / India',
    instructionsEn: 'Send funds to official PayPal: payments@fasttestprofit.com (Title: FASTTEST Global). Enter your PayPal Transaction ID below.',
    instructionsUr: 'Send funds to official PayPal: payments@fasttestprofit.com (Title: FASTTEST Global). Enter your PayPal Transaction ID below.'
  }
};

export function getDailyRoiRate(amountPKR: number): number {
  if (amountPKR >= 15000) return 20; // Rs. 15,000 -> 20% daily (+Rs. 3,000/day)
  if (amountPKR >= 10000) return 15; // Rs. 10,000 -> 15% daily (+Rs. 1,500/day)
  if (amountPKR >= 7000) return 10;  // Rs. 7,000 -> 10% daily (+Rs. 700/day)
  if (amountPKR >= 3000) return 10;  // Rs. 3,000 -> 10% daily (+Rs. 300/day)
  if (amountPKR >= 1000) return 7;   // Rs. 1,000 -> 7% daily (+Rs. 70/day)
  return 7;
}

export function getExpectedDailyProfit(amountPKR: number): number {
  if (amountPKR >= 15000) return Math.round(amountPKR * 0.20); // Rs. 3,000 for 15k
  if (amountPKR >= 10000) return Math.round(amountPKR * 0.15); // Rs. 1,500 for 10k
  if (amountPKR >= 7000) return Math.round(amountPKR * 0.10);  // Rs. 700 for 7k
  if (amountPKR >= 3000) return Math.round(amountPKR * 0.10);  // Rs. 300 for 3k
  if (amountPKR >= 1000) return 70;                            // Rs. 70 for 1k
  return Math.round(amountPKR * 0.07);
}

export const INITIAL_PLANS: InvestmentPlan[] = [
  {
    id: 'plan_1k',
    nameEn: '1,000 PKR Plan (7% Daily - Rs. 70)',
    nameUr: '1,000 روپے پلان (7% روزانہ منافع - 70 روپے)',
    minDepositPKR: 1000,
    maxDepositPKR: 1000,
    dailyRoiMin: 7,
    dailyRoiMax: 7,
    durationDays: 30,
    riskLevelEn: 'Starter Tier',
    riskLevelUr: 'اسٹارٹر ٹیئر',
    descriptionEn: 'Deposit 1,000 PKR and receive 7% daily profit (Rs. 70) credited every 24 hours.',
    descriptionUr: '1,000 روپے جمع کریں اور ہر 24 گھنٹے بعد 7% روزانہ منافع (70 روپے) حاصل کریں۔',
    isPopular: false
  },
  {
    id: 'plan_3k',
    nameEn: '3,000 PKR Plan (10% Daily - Rs. 300)',
    nameUr: '3,000 روپے پلان (10% روزانہ منافع - 300 روپے)',
    minDepositPKR: 3000,
    maxDepositPKR: 3000,
    dailyRoiMin: 10,
    dailyRoiMax: 10,
    durationDays: 30,
    riskLevelEn: 'Fast Growth',
    riskLevelUr: 'مقبول ترین پلان',
    descriptionEn: 'Deposit 3,000 PKR and receive 10% daily profit (Rs. 300) credited every 24 hours.',
    descriptionUr: '3,000 روپے جمع کریں اور ہر 24 گھنٹے بعد 10% روزانہ منافع (300 روپے) حاصل کریں۔',
    isPopular: true
  },
  {
    id: 'plan_7k',
    nameEn: '7,000 PKR Plan (10% Daily - Rs. 700)',
    nameUr: '7,000 روپے پلان (10% روزانہ منافع - 700 روپے)',
    minDepositPKR: 7000,
    maxDepositPKR: 7000,
    dailyRoiMin: 10,
    dailyRoiMax: 10,
    durationDays: 30,
    riskLevelEn: 'Silver Pool',
    riskLevelUr: 'سلور پول',
    descriptionEn: 'Deposit 7,000 PKR and receive 10% daily profit (Rs. 700) credited every 24 hours.',
    descriptionUr: '7,000 روپے جمع کریں اور ہر 24 گھنٹے بعد 10% روزانہ منافع (700 روپے) حاصل کریں۔',
    isPopular: false
  },
  {
    id: 'plan_10k',
    nameEn: '10,000 PKR Plan (15% Daily - Rs. 1,500)',
    nameUr: '10,000 روپے پلان (15% روزانہ منافع - 1,500 روپے)',
    minDepositPKR: 10000,
    maxDepositPKR: 10000,
    dailyRoiMin: 15,
    dailyRoiMax: 15,
    durationDays: 45,
    riskLevelEn: 'Growth Pool',
    riskLevelUr: 'گروتھ پول',
    descriptionEn: 'Deposit 10,000 PKR and receive 15% daily profit (Rs. 1,500) credited every 24 hours.',
    descriptionUr: '10,000 روپے جمع کریں اور ہر 24 گھنٹے بعد 15% روزانہ منافع (1,500 روپے) حاصل کریں۔',
    isPopular: false
  },
  {
    id: 'plan_15k',
    nameEn: '15,000 PKR Plan (20% Daily - Rs. 3,000)',
    nameUr: '15,000 روپے پلان (20% روزانہ منافع - 3,000 روپے)',
    minDepositPKR: 15000,
    maxDepositPKR: 100000,
    dailyRoiMin: 20,
    dailyRoiMax: 20,
    durationDays: 60,
    riskLevelEn: 'Elite VIP Pool',
    riskLevelUr: 'ایلیٹ وی آئی پی پول',
    descriptionEn: 'Deposit 15,000 PKR and receive 20% daily profit (Rs. 3,000) credited every 24 hours.',
    descriptionUr: '15,000 روپے جمع کریں اور ہر 24 گھنٹے بعد 20% روزانہ منافع (3,000 روپے) حاصل کریں۔',
    isPopular: false
  }
];

export const INITIAL_INVESTORS: Investor[] = [
  {
    id: 'inv_admin',
    name: 'Admin',
    email: 'admin@fasttestprofit.pk',
    phone: '03194815693',
    city: 'Pakistan',
    activePlanId: '',
    capitalInvestedPKR: 0,
    totalProfitEarnedPKR: 0,
    availableBalancePKR: 0,
    pendingWithdrawalPKR: 0,
    joinedDate: '2026-01-01',
    status: 'active'
  },
  {
    id: 'inv_user',
    name: 'User',
    email: 'user@fasttestprofit.pk',
    phone: '0300-1234567',
    city: 'Pakistan',
    activePlanId: '',
    capitalInvestedPKR: 0,
    totalProfitEarnedPKR: 0,
    availableBalancePKR: 0,
    pendingWithdrawalPKR: 0,
    joinedDate: '2026-01-01',
    status: 'active'
  }
];

export const INITIAL_DAILY_PROFITS: DailyProfitRecord[] = [];

export const INITIAL_TRADE_LOGS: TradeLog[] = [];

export const INITIAL_DEPOSIT_REQUESTS: DepositRequest[] = [];

export const INITIAL_WITHDRAWAL_REQUESTS: WithdrawalRequest[] = [];

export const INITIAL_TRANSACTIONS: Transaction[] = [];
