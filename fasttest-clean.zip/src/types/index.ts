export type Language = 'ur' | 'en';
export type Currency = 'PKR' | 'USD';

export interface InvestmentPlan {
  id: string;
  nameEn: string;
  nameUr: string;
  minDepositPKR: number; // e.g. 100 Rs
  maxDepositPKR: number; // e.g. 100,000 Rs
  dailyRoiMin: number; // e.g. 1.2%
  dailyRoiMax: number; // e.g. 1.8%
  durationDays: number;
  riskLevelEn: string;
  riskLevelUr: string;
  descriptionEn: string;
  descriptionUr: string;
  isPopular?: boolean;
}

export interface Investor {
  id: string;
  name: string;
  email: string;
  phone: string;
  city: string;
  activePlanId: string;
  capitalInvestedPKR: number;
  totalProfitEarnedPKR: number;
  availableBalancePKR: number;
  pendingWithdrawalPKR: number;
  joinedDate: string;
  status: 'active' | 'paused' | 'blocked' | 'suspended';
  lastProfitTimestamp?: number;
  nextProfitTimestamp?: number;
  lastApprovedDepositAt?: number;
  referralCode?: string;
  referredByCode?: string;
  totalReferralEarningsPKR?: number;
  totalReferredUsersCount?: number;
  awardedBonusMilestones?: number;
}

export interface DailyProfitRecord {
  id: string;
  investorId: string;
  investorName: string;
  date: string;
  returnPercentage: number;
  amountPKR: number;
  strategyName: string;
  tradePair: string;
  status: 'credited';
}

export interface TradeLog {
  id: string;
  date: string;
  assetPair: string;
  action: 'BUY' | 'SELL';
  entryPrice: number;
  exitPrice: number;
  profitPercentage: number;
  pnlPKR: number;
  notes: string;
  status: 'CLOSED' | 'OPEN';
}

export type PaymentMethod = 'easypaisa' | 'jazzcash' | 'paytm' | 'paypal';
export type WithdrawalPaymentMethod = 'easypaisa' | 'jazzcash' | 'paytm' | 'paypal';

export interface DepositRequest {
  id: string;
  investorId: string;
  investorName: string;
  planId: string;
  amountPKR: number;
  paymentMethod: PaymentMethod;
  senderAccountNumber: string;
  transactionId: string;
  status: 'pending' | 'approved' | 'rejected';
  timestamp: string;
  adminNote?: string;
}

export interface WithdrawalRequest {
  id: string;
  investorId: string;
  investorName: string;
  amountPKR: number;
  paymentMethod: WithdrawalPaymentMethod;
  accountDetails: string;
  accountTitle: string;
  status: 'pending' | 'approved' | 'rejected';
  requestedAt: string;
  processedAt?: string;
  referenceId?: string;
}

export interface Transaction {
  id: string;
  investorId: string;
  type: 'DEPOSIT' | 'PROFIT' | 'WITHDRAWAL' | 'REFERRAL_COMMISSION';
  amountPKR: number;
  paymentMethod?: WithdrawalPaymentMethod;
  referenceId?: string;
  descriptionEn: string;
  descriptionUr: string;
  date: string;
  status: 'COMPLETED' | 'PENDING' | 'REJECTED';
}

export interface UserAccount {
  id: string;
  username: string;
  phone: string;
  password: string;
  investorId: string;
  createdAt: string;
  isBlocked?: boolean;
  referredBy?: string;
}
