export function downloadProjectZip() {
  const url = `/api/download-zip?t=${Date.now()}`;
  
  // Create an anchor and trigger direct click
  const a = document.createElement('a');
  a.href = url;
  a.download = 'fasttest-profit-daily.zip';
  a.target = '_blank';
  document.body.appendChild(a);
  a.click();

  setTimeout(() => {
    if (document.body.contains(a)) {
      document.body.removeChild(a);
    }
  }, 1000);
}
